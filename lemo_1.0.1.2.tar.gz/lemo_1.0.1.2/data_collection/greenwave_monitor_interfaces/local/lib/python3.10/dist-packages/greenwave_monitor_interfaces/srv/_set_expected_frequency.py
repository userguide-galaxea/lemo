# generated from rosidl_generator_py/resource/_idl.py.em
# with input from greenwave_monitor_interfaces:srv/SetExpectedFrequency.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SetExpectedFrequency_Request(type):
    """Metaclass of message 'SetExpectedFrequency_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('greenwave_monitor_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'greenwave_monitor_interfaces.srv.SetExpectedFrequency_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__set_expected_frequency__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__set_expected_frequency__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__set_expected_frequency__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__set_expected_frequency__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__set_expected_frequency__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SetExpectedFrequency_Request(metaclass=Metaclass_SetExpectedFrequency_Request):
    """Message class 'SetExpectedFrequency_Request'."""

    __slots__ = [
        '_topic_name',
        '_expected_hz',
        '_tolerance_percent',
        '_clear_expected',
        '_add_topic_if_missing',
    ]

    _fields_and_field_types = {
        'topic_name': 'string',
        'expected_hz': 'double',
        'tolerance_percent': 'double',
        'clear_expected': 'boolean',
        'add_topic_if_missing': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.topic_name = kwargs.get('topic_name', str())
        self.expected_hz = kwargs.get('expected_hz', float())
        self.tolerance_percent = kwargs.get('tolerance_percent', float())
        self.clear_expected = kwargs.get('clear_expected', bool())
        self.add_topic_if_missing = kwargs.get('add_topic_if_missing', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.topic_name != other.topic_name:
            return False
        if self.expected_hz != other.expected_hz:
            return False
        if self.tolerance_percent != other.tolerance_percent:
            return False
        if self.clear_expected != other.clear_expected:
            return False
        if self.add_topic_if_missing != other.add_topic_if_missing:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def topic_name(self):
        """Message field 'topic_name'."""
        return self._topic_name

    @topic_name.setter
    def topic_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'topic_name' field must be of type 'str'"
        self._topic_name = value

    @builtins.property
    def expected_hz(self):
        """Message field 'expected_hz'."""
        return self._expected_hz

    @expected_hz.setter
    def expected_hz(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'expected_hz' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'expected_hz' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._expected_hz = value

    @builtins.property
    def tolerance_percent(self):
        """Message field 'tolerance_percent'."""
        return self._tolerance_percent

    @tolerance_percent.setter
    def tolerance_percent(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'tolerance_percent' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'tolerance_percent' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._tolerance_percent = value

    @builtins.property
    def clear_expected(self):
        """Message field 'clear_expected'."""
        return self._clear_expected

    @clear_expected.setter
    def clear_expected(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'clear_expected' field must be of type 'bool'"
        self._clear_expected = value

    @builtins.property
    def add_topic_if_missing(self):
        """Message field 'add_topic_if_missing'."""
        return self._add_topic_if_missing

    @add_topic_if_missing.setter
    def add_topic_if_missing(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'add_topic_if_missing' field must be of type 'bool'"
        self._add_topic_if_missing = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_SetExpectedFrequency_Response(type):
    """Metaclass of message 'SetExpectedFrequency_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('greenwave_monitor_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'greenwave_monitor_interfaces.srv.SetExpectedFrequency_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__set_expected_frequency__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__set_expected_frequency__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__set_expected_frequency__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__set_expected_frequency__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__set_expected_frequency__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SetExpectedFrequency_Response(metaclass=Metaclass_SetExpectedFrequency_Response):
    """Message class 'SetExpectedFrequency_Response'."""

    __slots__ = [
        '_success',
        '_message',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value


class Metaclass_SetExpectedFrequency(type):
    """Metaclass of service 'SetExpectedFrequency'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('greenwave_monitor_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'greenwave_monitor_interfaces.srv.SetExpectedFrequency')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__set_expected_frequency

            from greenwave_monitor_interfaces.srv import _set_expected_frequency
            if _set_expected_frequency.Metaclass_SetExpectedFrequency_Request._TYPE_SUPPORT is None:
                _set_expected_frequency.Metaclass_SetExpectedFrequency_Request.__import_type_support__()
            if _set_expected_frequency.Metaclass_SetExpectedFrequency_Response._TYPE_SUPPORT is None:
                _set_expected_frequency.Metaclass_SetExpectedFrequency_Response.__import_type_support__()


class SetExpectedFrequency(metaclass=Metaclass_SetExpectedFrequency):
    from greenwave_monitor_interfaces.srv._set_expected_frequency import SetExpectedFrequency_Request as Request
    from greenwave_monitor_interfaces.srv._set_expected_frequency import SetExpectedFrequency_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
