from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription, OpaqueFunction, SetEnvironmentVariable, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
import os

# Default runtime profile.  Change these values here for the normal robot
# startup; every value can still be overridden with ``name:=value``.
DEFAULT_ARM = 'both'
DEFAULT_CTRL_HZ = '200'
# [OTG] 轨迹平滑(arm_bridge Ruckig 在线轨迹,移植自 171.5.1.17 v4 实机版):
# legacy(默认,现状行为)/ otg / v4(otg+preview 路点,需客户端配合)
# / pc(与 PC 版 bridge 一致——spike clamp 10°/step + vel FF + 200Hz 统一下发,
# 无位置低通,SDK 拒帧线保底;
#     推理训推动力学对齐 PC 采集链路时用)
# / cubic(preview 三次样条+SlewLimiter3 逐关节限幅,preview 断流回退 otg 语义,
#     cherry-pick 自 czd 分支 ActonChen 0dc885b/d89542f)
# / bcubic(后向样条:最近 4 目标点 Catmull-Rom 采样+同一 SlewLimiter3,无
#     preview 依赖——遥操/推理同一模式,采训推执行动力学一致;滞后 1-2 帧)。
# otg/v4/cubic/bcubic 强制 ctrl_hz=200 与 URDF 关节限位;限值取 .17 v4 实机验证值,
# restart-only(改 arm_smoothing_mode/trajectory_* 需重启 arm_bridge)。
DEFAULT_ARM_SMOOTHING = 'legacy'
# [run_mode 门控] arm_bridge 消费端强制(/motion_target/* 源标签按模式校验,
# 契约见 README「统一运行模式」节):observe(默认,只告警+计数,观察期)
# / enforce(丢弃非许可源帧)。restart-only。
DEFAULT_TARGET_GATE = 'observe'
# OTG 限值默认档:2.5/12/120 是 .17 推理场景(15Hz 目标)验证值;
# 遥操跟手度敏感,可用 arm_smooth_vmax/amax/jerk 现场放宽
# (vmax 上限 3.5——SDK 命令速度硬限 4.0,留 0.5 余量;jerk 越大越跟手
# 但加速度切换越硬,振动/异响随之上升)。
DEFAULT_ARM_SMOOTH_VMAX = '2.5'    # rad/s
DEFAULT_ARM_SMOOTH_AMAX = '12'     # rad/s^2
DEFAULT_ARM_SMOOTH_JERK = '120'    # rad/s^3
# 硬件 profile 三级配置体系(scripts/lemo_profile.py):
# gripper:= g2/g2_mit/g1z(别名 lemo=g2, old=g1z), leader:= evt/dvt。
# 'auto' = 读 /etc/lemo/machine.yaml;文件不存在回退 g2+evt(WARN 未注册)。
# 显式参数优先于 machine.yaml。校验不过(未知名/缺字段/组合不支持/SDK 缺
# GripperV2)启动直接报错,不拉起任何节点。
DEFAULT_GRIPPER = 'auto'
DEFAULT_LEADER = 'auto'
# 采集层: 本仓库重构版 g4_spi + camera_publisher(分离部署)。
# 一体版 lemo_main_board 已于 2026-09-22 停用(COLCON_IGNORE):teleop 切回
# g4_spi/msg 后一体版消息类型不互通,use_main_board 路径与参数一并移除。
DEFAULT_START_G4SPI = 'true'
DEFAULT_START_CAMERA = 'true'
DEFAULT_START_RECORDING = 'true'
DEFAULT_CAMERA_HZ = '15'
DEFAULT_CAMERA_ROTATION_DEG = '0'
# 固定曝光(µs)：2026-09-11 梯度实验拍板(SOP §7-19:亮度/锐度/过曝/满帧率综合最优 20000 us;16667 偏暗)。
# 0=自动曝光，目前采用20000(us)固定曝光时间。
DEFAULT_CAMERA_EXPOSURE_US = '10000'
# 如需机器人启动即带 Web 状态仪表盘（0.0.0.0:8000），改为 'true' 或启动时传 start_dashboard:=true
DEFAULT_START_DASHBOARD = 'true'
# start_policy:=true 时启动 policy_client（WebSocket 推理策略客户端），
# 以 policy 输出的 /motion_target/* 替代 leader 遥操作为目标源
DEFAULT_START_POLICY = 'false'
# 推理相关默认值取自 /etc/lemo/machine.yaml 的 policy: 段(可选)——
# 机器相关值(server 地址/任务描述/平滑)与硬件档案同文件集中管理;
# 命令行参数优先于文件。policy 段不属 lemo_profile 校验 schema,纯可选。
def _load_machine_policy_defaults():
    try:
        import yaml
        with open('/etc/lemo/machine.yaml', encoding='utf-8') as f:
            d = yaml.safe_load(f) or {}
        p = d.get('policy')
        return p if isinstance(p, dict) else {}
    except Exception:
        return {}

_POLICY_M = _load_machine_policy_defaults()
DEFAULT_POLICY_SERVER_URL = str(
    _POLICY_M.get('server_url') or 'ws://192.168.110.62:8765')
DEFAULT_POLICY_TASK = str(_POLICY_M.get('task') or '')
DEFAULT_POLICY_EMBODIMENT = str(_POLICY_M.get('embodiment') or 'galaxea_a1z')
DEFAULT_POLICY_SEND_RAW_JPEG = str(
    _POLICY_M.get('send_raw_jpeg', True)).lower()
# 推理/播包源专用平滑(遥操仍走 arm_smoothing);配了 smoothing 时其限值档
# 同时成为默认
DEFAULT_ARM_SMOOTHING_POLICY = str(_POLICY_M.get('smoothing') or '')
if _POLICY_M.get('smoothing'):
    DEFAULT_ARM_SMOOTH_VMAX = str(_POLICY_M.get('smooth_vmax') or DEFAULT_ARM_SMOOTH_VMAX)
    DEFAULT_ARM_SMOOTH_AMAX = str(_POLICY_M.get('smooth_amax') or DEFAULT_ARM_SMOOTH_AMAX)
    DEFAULT_ARM_SMOOTH_JERK = str(_POLICY_M.get('smooth_jerk') or DEFAULT_ARM_SMOOTH_JERK)
# poll_hz 必须 2000(对齐老栈 g4spi.service):固件上行缓冲浅,1kHz 轮询
# 抽不干净 → 线上单帧丢包积压成 300-400ms 反馈断流 → FEEDBACK_STALE/
# FAULT_HOLD(臂走到一半不跟随再陡恢复,Z012 2026-09-20 实机对照确认)。
DEFAULT_G4SPI_POLL_HZ = '2000'
DEFAULT_G4SPI_SPI_SPEED_HZ = '20000000'
DEFAULT_LINUX_VERSION = '1.0.1.2'
# ROS 日志默认写 tmpfs(/dev/shm/ros_log):eMMC 写 stall 不卡实时链、零磨损;
# lemo-log-rotate 每 5min 把静置日志搬到 ~/.ros/log 存档(断网掉电丢未搬部分)。
# 需要直写 eMMC 时: ros2 launch lemo lemo.launch.py log_dir:=~/.ros/log
DEFAULT_LOG_DIR = '/dev/shm/ros_log'
DEFAULT_RCUTILS_CONSOLE_OUTPUT_FORMAT = \
    '[{severity}] [{date_time_with_ms}] [{name}]: {message}'

# launch itself starts logging before LaunchDescription actions are executed.
# Set the default here so launch.log and child-node logs share the ROS log tree.
os.makedirs(DEFAULT_LOG_DIR, exist_ok=True)
os.environ['ROS_LOG_DIR'] = DEFAULT_LOG_DIR
os.environ.setdefault('RCUTILS_CONSOLE_OUTPUT_FORMAT',
                      DEFAULT_RCUTILS_CONSOLE_OUTPUT_FORMAT)

# With --symlink-install this file in the package share directory is a
# symlink to <workspace>/launch. Resolve it before deriving the vendor path.
_LAUNCH_SOURCE_DIR = os.path.dirname(os.path.realpath(__file__))
# data_collection 预编译 overlay 路径两种布局都要能找到:
#   symlink-install: realpath 指回源码树 <ws>/launch -> ../src/...
#   拷贝安装(普通 colcon build): install/lemo/share/lemo/launch -> 上五级回工作区根
_dc_candidates = [
    # Binary release: <release>/install/lemo/share/lemo/launch.
    os.path.join(_LAUNCH_SOURCE_DIR, '..', '..', '..', '..', '..',
                 'data_collection'),
    os.path.join(_LAUNCH_SOURCE_DIR, '..', 'src', 'data_collection', 'install'),
    os.path.join(_LAUNCH_SOURCE_DIR, '..', '..', '..', '..', '..',
                 'src', 'data_collection', 'install'),
]
DEFAULT_DATA_COLLECTION_INSTALL = next(
    (os.path.abspath(p) for p in _dc_candidates
     if os.path.isfile(os.path.join(p, 'local_setup.bash'))),
    os.path.abspath(_dc_candidates[0]))

def optional_policy_launch(context):
    """仅在显式启用策略时才查找可选的 policy_client 包。"""
    enabled = LaunchConfiguration('start_policy').perform(context).lower()
    if enabled not in ('true', '1', 'yes', 'on'):
        return []
    # 平滑全部由运控(arm_bridge)承担时,客户端不插帧:轨迹生成类模式
    # (otg/v4/cubic/bcubic)自带稀疏→200Hz 重采样;pc/legacy 直通类需要
    # 客户端中点插值补密度(15→30Hz)
    smoothing = LaunchConfiguration('arm_smoothing').perform(context)
    interp_default = 'false' if smoothing in ('otg', 'v4', 'cubic', 'bcubic') \
        else 'true'
    interp = LaunchConfiguration('policy_interp_midpoint').perform(context)
    if interp.lower() not in ('true', 'false', '1', '0', 'yes', 'no'):
        interp = interp_default   # auto
    return [IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('policy_client'), 'launch', 'policy_client.launch.py')),
        launch_arguments={
            'server_url': LaunchConfiguration('policy_server_url'),
            'task': LaunchConfiguration('policy_task'),
            'send_raw_jpeg': LaunchConfiguration('policy_send_raw_jpeg'),
            'embodiment_type': LaunchConfiguration('policy_embodiment'),
            'enabled': LaunchConfiguration('policy_enabled'),
            'max_joint_step_deg': LaunchConfiguration('policy_max_joint_step_deg'),
            'prefetch_steps': LaunchConfiguration('policy_prefetch_steps'),
            'interp_midpoint': interp,
        }.items())]

def _import_profile_loader():
    """定位并 import scripts/lemo_profile.py(源码树与 share 安装两种布局)。"""
    import importlib.util
    candidates = [
        # symlink-install: realpath 指回源码仓 launch/ -> ../scripts/
        os.path.join(_LAUNCH_SOURCE_DIR, '..', 'scripts', 'lemo_profile.py'),
        # 非 symlink 安装: share/lemo/launch/ -> ../scripts/
        os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     '..', 'scripts', 'lemo_profile.py'),
    ]
    for path in candidates:
        if os.path.isfile(path):
            spec = importlib.util.spec_from_file_location('lemo_profile', path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    raise RuntimeError(
        '[lemo.launch] 找不到 lemo_profile.py,查找路径: %s' % ', '.join(candidates))


def _deep_merge(base, overrides):
    """把 overrides 深合并进 base(dict),返回 base。"""
    for k, v in overrides.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
    return base


def gripper_stack(context):
    """按硬件 profile 生成 teleop + 双臂 arm_bridge 节点。

    gripper/leader 经 scripts/lemo_profile.py 三级 profile 体系解析
    (machine.yaml 常态 + launch 参数覆盖):
      gripper profile -> arm_bridge ROS 参数 dict + teleop 两态/连续语义
      leader profile  -> teleop 的 signs/offsets/ticks(合并基准 teleop.yaml
                         生成临时文件,经 config_path 传入)
    任何校验不过在此 raise,launch 直接失败,不拉起任何节点。
    """
    import tempfile
    import yaml
    lemo_profile = _import_profile_loader()
    raw_gripper = LaunchConfiguration('gripper').perform(context).strip().lower()
    raw_leader = LaunchConfiguration('leader').perform(context).strip().lower()
    gripper_arg = None if raw_gripper in ('', 'auto') else \
        {'lemo': 'g2', 'old': 'g1z'}.get(raw_gripper, raw_gripper)
    leader_arg = None if raw_leader in ('', 'auto') else raw_leader
    sel = lemo_profile.load(gripper=gripper_arg, leader=leader_arg)
    for warn in sel['warnings']:
        print('[lemo.launch] WARN: %s' % warn)
    # 生效组合横幅(三行,日志可见)
    print(sel['banner'])

    # teleop: 基准 teleop.yaml + profile 覆盖 -> 临时合并 yaml
    base_config = os.path.join(
        get_package_share_directory('lemo'), 'config', 'teleop.yaml')
    with open(base_config, 'r') as f:
        teleop_cfg = yaml.safe_load(f)
    _deep_merge(teleop_cfg, lemo_profile.teleop_overrides(sel))
    fd, teleop_merged = tempfile.mkstemp(
        prefix='lemo_teleop_profile_', suffix='.yaml', dir=DEFAULT_LOG_DIR)
    with os.fdopen(fd, 'w') as f:
        yaml.safe_dump(teleop_cfg, f, allow_unicode=True, sort_keys=False)
    print('[lemo.launch] teleop 合并配置: %s (基准: %s)'
          % (teleop_merged, os.path.basename(base_config)))

    arm = LaunchConfiguration('arm')
    hz = LaunchConfiguration('ctrl_hz')
    gripper_model = sel['gripper']['profile']['model']
    teleop_node = Node(
        package='lemo', executable='teleop_bridge_node', name='teleop_bridge',
        output='both',
        parameters=[{'config_path': teleop_merged,
                     'control_hz': ParameterValue(hz, value_type=float),
                     'gripper_profile': gripper_model}])
    # g4spi 先完成 DDS 发现和 SPI 收包；否则双臂启动探测会在订阅匹配前超时。
    # 桥接节点几乎立即就绪,arm_bridge 订阅匹配(桥接侧)3s 足够。
    arm_params_left = lemo_profile.arm_bridge_params(sel)
    arm_params_right = lemo_profile.arm_bridge_params(sel)
    # [OTG] 平滑模式透传 + 限值(legacy 下三组限值惰性,仅构造校验);
    # 限值经 arm_smooth_vmax/amax/jerk 标量参数全关节同值下发,现场可调。
    def _six(name):
        return [float(LaunchConfiguration(name).perform(context))] * 6
    smoothing_params = {
        'arm_smoothing_mode': LaunchConfiguration('arm_smoothing'),
        'policy_smoothing_mode': LaunchConfiguration('arm_smoothing_policy'),
        'trajectory_max_velocity': _six('arm_smooth_vmax'),
        'trajectory_max_acceleration': _six('arm_smooth_amax'),
        'trajectory_max_jerk': _six('arm_smooth_jerk'),
        'target_gate': LaunchConfiguration('arm_target_gate'),
    }
    arm_params_left.update(smoothing_params)
    arm_params_right.update(smoothing_params)
    arm_params_left.update({'arm': 'left', 'transport': 'g4ros',
                            'ctrl_hz': ParameterValue(hz, value_type=int)})
    arm_params_right.update({'arm': 'right', 'transport': 'g4ros',
                             'ctrl_hz': ParameterValue(hz, value_type=int)})
    arm_nodes = TimerAction(period=3.0, actions=[
        Node(package='a1z_arm_bridge_sdk', executable='arm_bridge_node', name='arm_bridge_left', output='both', condition=IfCondition(PythonExpression(["'", arm, "' in ['left','both']"])), parameters=[arm_params_left]),
        Node(package='a1z_arm_bridge_sdk', executable='arm_bridge_node', name='arm_bridge_right', output='both', condition=IfCondition(PythonExpression(["'", arm, "' in ['right','both']"])), parameters=[arm_params_right]),
    ])
    return [teleop_node, arm_nodes]

def generate_launch_description():
    # 相机默认值按 machine.yaml(第二步接线):hz/翻转/曝光以本机档案为准,
    # 显式 camera_* launch 参数仍可覆盖;machine.yaml 缺失/非法回退内置常量。
    lemo_profile = _import_profile_loader()
    cam_hz, cam_rot, cam_exp = DEFAULT_CAMERA_HZ, DEFAULT_CAMERA_ROTATION_DEG, DEFAULT_CAMERA_EXPOSURE_US
    try:
        _m = lemo_profile.load().get('machine')
        if _m:
            cam_hz = str(_m['camera']['hz'])
            cam_rot = str(_m['camera']['wrist_rotation_deg'])
            cam_exp = str(_m['camera']['exposure_us'])
    except Exception as _e:
        print('[lemo.launch] machine.yaml 相机参数读取失败,用内置默认: %s' % _e)

    # Fast DDS Discovery Server 客户端 profile 兜底:bashrc 只在交互式 shell
    # 生效,非交互 ssh/脚本/tmux 起栈会漏掉 FASTRTPS_DEFAULT_PROFILES_FILE
    # (表现为 XMLPARSER 报 ./DEFAULT_FASTRTPS_PROFILES.xml 不存在,Discovery
    # 静默失效,首帧不齐问题回归)。
    # 三级兜底,任一存在即注入,任何启动路径都不出错:
    #   1) /etc/lemo/super_client.xml(setup 安装位)
    #   2) 仓库自带 deploy/discovery/super_client.xml(/etc 被清也能活)
    # 都没有则 WARN 明示走默认组播,不再静默。
    dds_env = []
    if not os.environ.get('FASTRTPS_DEFAULT_PROFILES_FILE'):
        _repo_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        for _p in ('/etc/lemo/super_client.xml',
                   os.path.join(_repo_root, 'deploy', 'discovery', 'super_client.xml')):
            if os.path.exists(_p):
                print('[lemo.launch] FASTRTPS_DEFAULT_PROFILES_FILE 未设置,自动注入 %s' % _p)
                dds_env.append(SetEnvironmentVariable('FASTRTPS_DEFAULT_PROFILES_FILE', _p))
                break
        else:
            print('[lemo.launch][WARN] 未找到 super_client.xml,Fast DDS 走默认组播'
                  '(Discovery Server 不生效;请重跑 scripts/lemo_setup.sh)')
    # Fast DDS 2.6 loadDefaultXMLFile 在加载 env profile 后仍无条件探测
    # CWD/DEFAULT_FASTRTPS_PROFILES.xml,不存在则打一条 XMLPARSER Error——
    # 纯属噪音(profile 已生效),官方开关 SKIP_DEFAULT_XML_FILE=1 关闭该探测。
    if not os.environ.get('SKIP_DEFAULT_XML_FILE'):
        dds_env.append(SetEnvironmentVariable('SKIP_DEFAULT_XML_FILE', '1'))

    legacy_g4spi_on = PythonExpression(["'", LaunchConfiguration('start_g4spi'), "'=='true'"])
    legacy_camera_on = PythonExpression(["'", LaunchConfiguration('start_camera'), "'=='true'"])
    return LaunchDescription([
        *dds_env,
        DeclareLaunchArgument('arm', default_value=DEFAULT_ARM, description='left, right or both'),
        DeclareLaunchArgument('ctrl_hz', default_value=DEFAULT_CTRL_HZ, description='arm control frequency in Hz'),
        DeclareLaunchArgument('arm_smoothing', default_value=DEFAULT_ARM_SMOOTHING,
                              description='arm_bridge 轨迹平滑: legacy(默认,现状)/ otg(Ruckig 在线轨迹)/ v4(otg+preview,需客户端)/ pc(PC bridge 语义:spike clamp+vel FF+200Hz 统一下发,无位置低通,SDK 拒帧线 7.0 保底)/ cubic(preview 三次样条+SlewLimiter3 逐关节限幅)/ bcubic(后向样条); otg/v4/cubic/bcubic 强制 ctrl_hz=200'),
        DeclareLaunchArgument('arm_smoothing_policy', default_value=DEFAULT_ARM_SMOOTHING_POLICY,
                              description='推理/播包源专用平滑模式(空=与遥操同 arm_smoothing);典型: arm_smoothing:=legacy arm_smoothing_policy:=bcubic ——遥操手感+推理丝滑一次起栈'),
        DeclareLaunchArgument('arm_smooth_vmax', default_value=DEFAULT_ARM_SMOOTH_VMAX,
                              description='OTG 关节速度上限 rad/s(全关节同值,≤3.5;遥操不跟手可放宽)'),
        DeclareLaunchArgument('arm_smooth_amax', default_value=DEFAULT_ARM_SMOOTH_AMAX,
                              description='OTG 关节加速度上限 rad/s^2'),
        DeclareLaunchArgument('arm_smooth_jerk', default_value=DEFAULT_ARM_SMOOTH_JERK,
                              description='OTG 关节 jerk 上限 rad/s^3(越大越跟手,振动越明显)'),
        DeclareLaunchArgument('arm_target_gate', default_value=DEFAULT_TARGET_GATE,
                              description='run_mode 门控: observe(默认,只告警计数)/enforce(丢弃非许可源帧)'),
        DeclareLaunchArgument('gripper', default_value=DEFAULT_GRIPPER,
                              description='夹爪 profile: auto(默认,读 /etc/lemo/machine.yaml)/g2/g2_mit/g1z,别名 lemo=g2, old=g1z'),
        DeclareLaunchArgument('leader', default_value=DEFAULT_LEADER,
                              description='leader 臂 profile: auto(默认,读 /etc/lemo/machine.yaml)/evt(老款,J3反向)/dvt(新款,J3正向)'),
        DeclareLaunchArgument('start_g4spi', default_value=DEFAULT_START_G4SPI),
        DeclareLaunchArgument('start_camera', default_value=DEFAULT_START_CAMERA),
        DeclareLaunchArgument('start_recording', default_value=DEFAULT_START_RECORDING),
        DeclareLaunchArgument('camera_hz', default_value=cam_hz),
        DeclareLaunchArgument('camera_rotation_deg', default_value=cam_rot),
        DeclareLaunchArgument('camera_exposure_us', default_value=cam_exp),
        DeclareLaunchArgument('start_dashboard', default_value=DEFAULT_START_DASHBOARD,
                              description='start the web status dashboard (0.0.0.0:8000)'),
        DeclareLaunchArgument('start_policy', default_value=DEFAULT_START_POLICY,
                              description='start the policy client (WebSocket inference policy)'),
        DeclareLaunchArgument('policy_server_url', default_value=DEFAULT_POLICY_SERVER_URL,
                              description='policy server WebSocket URL'),
        DeclareLaunchArgument('policy_task', default_value=DEFAULT_POLICY_TASK,
                              description='任务描述文本（随 obs 发给 policy，如 "Pick up the red block."）'),
        DeclareLaunchArgument('policy_send_raw_jpeg', default_value=DEFAULT_POLICY_SEND_RAW_JPEG,
                              description='true: 相机 JPEG 原字节发 server 端解码（默认，板端零解码）；'
                                          'false: 板端解码 resize 发 CHW（兼容老 server）'),
        DeclareLaunchArgument('policy_embodiment', default_value=DEFAULT_POLICY_EMBODIMENT,
                              description='G0.5 embodiment 名,须与 server eval_embodiment 一致'),
        DeclareLaunchArgument('policy_enabled', default_value='true',
                              description='policy 总开关;false 时只连不发 /motion_target(首次联调建议 false)'),
        DeclareLaunchArgument('policy_max_joint_step_deg', default_value='10',
                              description='policy_client 单帧关节增量限幅(度)'),
        DeclareLaunchArgument('policy_prefetch_steps', default_value='20',
                              description='policy_client 水位预取步数'),
        DeclareLaunchArgument('policy_interp_midpoint', default_value='auto',
                              description='客户端中点插值: auto(默认,轨迹类平滑关/直通类开)/true/false'),
        DeclareLaunchArgument('g4spi_poll_hz', default_value=DEFAULT_G4SPI_POLL_HZ),
        DeclareLaunchArgument('g4spi_spi_speed_hz', default_value=DEFAULT_G4SPI_SPI_SPEED_HZ),
        DeclareLaunchArgument('g4spi_a1z_spi_mode', default_value='batch',
                              description='A1Z SPI mode: batch sends left/right frames as 0x11/0x12'),
        DeclareLaunchArgument('linux_version', default_value=DEFAULT_LINUX_VERSION,
                              description='LEMO Linux software version shown by the dashboard'),
        DeclareLaunchArgument('data_collection_install', default_value=DEFAULT_DATA_COLLECTION_INSTALL),
        DeclareLaunchArgument('log_dir', default_value=DEFAULT_LOG_DIR,
                              description='ROS2 log directory (one file set per node)'),
        SetEnvironmentVariable('ROS_LOG_DIR', LaunchConfiguration('log_dir')),
        SetEnvironmentVariable('RCUTILS_CONSOLE_OUTPUT_FORMAT',
                               os.environ['RCUTILS_CONSOLE_OUTPUT_FORMAT']),
        SetEnvironmentVariable('LEMO_LINUX_VERSION', LaunchConfiguration('linux_version')),
        # 消息类型统一为 g4_spi/msg(teleop/dashboard/arm_bridge 全链);
        # 一体版 lemo_main_board 与 mainboard_bridge 均已停用(COLCON_IGNORE)。
        Node(package='g4_spi', executable='g4spi_node', name='g4spi_node', output='both', condition=IfCondition(legacy_g4spi_on), parameters=[{'poll_hz': LaunchConfiguration('g4spi_poll_hz'), 'spi_speed_hz': LaunchConfiguration('g4spi_spi_speed_hz'), 'a1z_spi_mode': LaunchConfiguration('g4spi_a1z_spi_mode')}]),
        Node(package='camera_publisher', executable='camera_publisher_node', name='camera_publisher', output='both', condition=IfCondition(legacy_camera_on), arguments=[LaunchConfiguration('camera_hz'), LaunchConfiguration('camera_rotation_deg'), LaunchConfiguration('camera_exposure_us')]),
        # sys_monitor is deliberately started last, after camera/g4spi and the
        # other graph nodes have had time to initialize.
        # teleop + 双臂 arm_bridge 按 gripper profile 生成(选 yaml+传参,见上)
        OpaqueFunction(function=gripper_stack),
        ExecuteProcess(
            cmd=['bash', '-c', 'exec bash "$(ros2 pkg prefix lemo)/share/lemo/scripts/start_data_collection.sh"'],
            additional_env={'DATA_COLLECTION_INSTALL': LaunchConfiguration('data_collection_install')},
            condition=IfCondition(LaunchConfiguration('start_recording')),
            output='both'),
        ExecuteProcess(
            # Dashboard 只负责可视化：限制到单独大核并降低 nice，避免三路
            # MJPEG 预览在录制控制时抢占 G4SPI/双臂控制调度。
            cmd=['bash', '-lc', 'exec nice -n 10 ros2 run lemo_dashboard lemo-dashboard -- --cpu-affinity 6 --stream-fps 3'],
            condition=IfCondition(LaunchConfiguration('start_dashboard')),
            output='both'),
        OpaqueFunction(function=optional_policy_launch),
        TimerAction(period=5.0, actions=[
            Node(package='sys_monitor', executable='sys_monitor', name='sys_monitor', output='both',
                 parameters=[{'camera_hz': ParameterValue(
                     LaunchConfiguration('camera_hz'), value_type=float)}])
        ]),
    ])
