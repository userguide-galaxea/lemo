#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibResult() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibResult__init(msg: *mut LidarCalibResult) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibResult>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibResult>);
    fn sensor_lidar_msg__msg__LidarCalibResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibResult>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibResult>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibResult__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibResult where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibResult() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationProgressResult() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibrationProgressResult__init(msg: *mut LidarCalibrationProgressResult) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationProgressResult>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationProgressResult>);
    fn sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibrationProgressResult>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationProgressResult>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibrationProgressResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationProgressResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibrationProgressResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibrationProgressResult__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibrationProgressResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibrationProgressResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationProgressResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationProgressResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibrationProgressResult where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibrationProgressResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationProgressResult() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResult() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibrationResult__init(msg: *mut LidarCalibrationResult) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResult>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResult>);
    fn sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibrationResult>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResult>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_result: super::super::msg::rmw::LidarCalibResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub horizont_result: super::super::msg::rmw::LidarHorizontResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rotation_result: super::super::msg::rmw::LidarRotationResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub canmsg_result: u8,

}



impl Default for LidarCalibrationResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibrationResult__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibrationResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibrationResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibrationResult where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibrationResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResult() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResultRequest() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibrationResultRequest__init(msg: *mut LidarCalibrationResultRequest) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultRequest>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultRequest>);
    fn sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibrationResultRequest>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultRequest>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResultRequest
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResultRequest {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::super::msg::rmw::LidarCalibrationType,

}



impl Default for LidarCalibrationResultRequest {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibrationResultRequest__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibrationResultRequest__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibrationResultRequest {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultRequest__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResultRequest {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibrationResultRequest where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibrationResultRequest";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResultRequest() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResultResponse() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibrationResultResponse__init(msg: *mut LidarCalibrationResultResponse) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultResponse>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultResponse>);
    fn sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibrationResultResponse>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationResultResponse>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResultResponse
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResultResponse {

    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_result_res: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LidarCalibrationResult>,

}



impl Default for LidarCalibrationResultResponse {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibrationResultResponse__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibrationResultResponse__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibrationResultResponse {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationResultResponse__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResultResponse {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibrationResultResponse where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibrationResultResponse";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationResultResponse() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationType() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarCalibrationType__init(msg: *mut LidarCalibrationType) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationType__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationType>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarCalibrationType__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationType>);
    fn sensor_lidar_msg__msg__LidarCalibrationType__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarCalibrationType>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarCalibrationType>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarCalibrationType
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationType {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibrationType {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarCalibrationType__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarCalibrationType__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarCalibrationType {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationType__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationType__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarCalibrationType__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationType {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarCalibrationType where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarCalibrationType";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarCalibrationType() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarError() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarError__init(msg: *mut LidarError) -> bool;
    fn sensor_lidar_msg__msg__LidarError__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarError>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarError__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarError>);
    fn sensor_lidar_msg__msg__LidarError__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarError>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarError>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarError
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarError {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mems_initialization_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mems_operating_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_transmitting_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_receiving_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_fusa_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub window_contamination_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sun_blind_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub window_heating_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_internal_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_external_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_internal_volt_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_temp_err: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub clock_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sync_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved1: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved2: u8,

}



impl Default for LidarError {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarError__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarError__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarError {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarError__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarError__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarError__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarError {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarError where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarError";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarError() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarErrorReport() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarErrorReport__init(msg: *mut LidarErrorReport) -> bool;
    fn sensor_lidar_msg__msg__LidarErrorReport__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarErrorReport>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarErrorReport__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarErrorReport>);
    fn sensor_lidar_msg__msg__LidarErrorReport__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarErrorReport>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarErrorReport>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarErrorReport
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarErrorReport {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_mode: u32,

}



impl Default for LidarErrorReport {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarErrorReport__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarErrorReport__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarErrorReport {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorReport__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorReport__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorReport__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarErrorReport {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarErrorReport where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarErrorReport";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarErrorReport() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarErrorStatus() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarErrorStatus__init(msg: *mut LidarErrorStatus) -> bool;
    fn sensor_lidar_msg__msg__LidarErrorStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarErrorStatus>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarErrorStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarErrorStatus>);
    fn sensor_lidar_msg__msg__LidarErrorStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarErrorStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarErrorStatus>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarErrorStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarErrorStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LidarErrorReport>,

}



impl Default for LidarErrorStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarErrorStatus__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarErrorStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarErrorStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarErrorStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarErrorStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarErrorStatus where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarErrorStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarErrorStatus() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarHorizontResult() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarHorizontResult__init(msg: *mut LidarHorizontResult) -> bool;
    fn sensor_lidar_msg__msg__LidarHorizontResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarHorizontResult>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarHorizontResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarHorizontResult>);
    fn sensor_lidar_msg__msg__LidarHorizontResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarHorizontResult>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarHorizontResult>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarHorizontResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarHorizontResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarHorizontResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarHorizontResult__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarHorizontResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarHorizontResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarHorizontResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarHorizontResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarHorizontResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarHorizontResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarHorizontResult where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarHorizontResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarHorizontResult() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarID() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarID__init(msg: *mut LidarID) -> bool;
    fn sensor_lidar_msg__msg__LidarID__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarID>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarID__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarID>);
    fn sensor_lidar_msg__msg__LidarID__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarID>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarID>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarID
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarID {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u32,

}



impl Default for LidarID {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarID__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarID__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarID {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarID__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarID__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarID__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarID {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarID where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarID";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarID() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarMode() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarMode__init(msg: *mut LidarMode) -> bool;
    fn sensor_lidar_msg__msg__LidarMode__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarMode>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarMode__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarMode>);
    fn sensor_lidar_msg__msg__LidarMode__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarMode>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarMode>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarMode
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarMode {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarMode {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarMode__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarMode__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarMode {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarMode__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarMode__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarMode__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarMode {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarMode where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarMode";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarMode() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarModeRequest() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarModeRequest__init(msg: *mut LidarModeRequest) -> bool;
    fn sensor_lidar_msg__msg__LidarModeRequest__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarModeRequest>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarModeRequest__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarModeRequest>);
    fn sensor_lidar_msg__msg__LidarModeRequest__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarModeRequest>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarModeRequest>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarModeRequest
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarModeRequest {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: super::super::msg::rmw::LidarMode,

}



impl Default for LidarModeRequest {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarModeRequest__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarModeRequest__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarModeRequest {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeRequest__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeRequest__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeRequest__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarModeRequest {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarModeRequest where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarModeRequest";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarModeRequest() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarModeResponse() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarModeResponse__init(msg: *mut LidarModeResponse) -> bool;
    fn sensor_lidar_msg__msg__LidarModeResponse__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarModeResponse>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarModeResponse__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarModeResponse>);
    fn sensor_lidar_msg__msg__LidarModeResponse__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarModeResponse>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarModeResponse>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarModeResponse
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarModeResponse {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_mode_resp: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LidarModeRequest>,

}



impl Default for LidarModeResponse {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarModeResponse__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarModeResponse__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarModeResponse {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeResponse__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeResponse__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarModeResponse__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarModeResponse {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarModeResponse where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarModeResponse";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarModeResponse() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarNotificationAck() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarNotificationAck__init(msg: *mut LidarNotificationAck) -> bool;
    fn sensor_lidar_msg__msg__LidarNotificationAck__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarNotificationAck>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarNotificationAck__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarNotificationAck>);
    fn sensor_lidar_msg__msg__LidarNotificationAck__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarNotificationAck>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarNotificationAck>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarNotificationAck
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarNotificationAck {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ack: u8,

}



impl Default for LidarNotificationAck {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarNotificationAck__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarNotificationAck__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarNotificationAck {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarNotificationAck__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarNotificationAck__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarNotificationAck__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarNotificationAck {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarNotificationAck where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarNotificationAck";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarNotificationAck() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarRotationResult() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarRotationResult__init(msg: *mut LidarRotationResult) -> bool;
    fn sensor_lidar_msg__msg__LidarRotationResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarRotationResult>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarRotationResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarRotationResult>);
    fn sensor_lidar_msg__msg__LidarRotationResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarRotationResult>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarRotationResult>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarRotationResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarRotationResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarRotationResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarRotationResult__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarRotationResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarRotationResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarRotationResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarRotationResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarRotationResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarRotationResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarRotationResult where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarRotationResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarRotationResult() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarStatus() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarStatus__init(msg: *mut LidarStatus) -> bool;
    fn sensor_lidar_msg__msg__LidarStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarStatus>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarStatus>);
    fn sensor_lidar_msg__msg__LidarStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarStatus>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::super::msg::rmw::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub progress_result: super::super::msg::rmw::LidarCalibrationProgressResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_progress: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error: super::super::msg::rmw::LidarError,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_mode: u32,

}



impl Default for LidarStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarStatus__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarStatus where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarStatus() }
  }
}


#[link(name = "sensor_lidar_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarStatusReport() -> *const std::ffi::c_void;
}

#[link(name = "sensor_lidar_msg__rosidl_generator_c")]
extern "C" {
    fn sensor_lidar_msg__msg__LidarStatusReport__init(msg: *mut LidarStatusReport) -> bool;
    fn sensor_lidar_msg__msg__LidarStatusReport__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LidarStatusReport>, size: usize) -> bool;
    fn sensor_lidar_msg__msg__LidarStatusReport__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LidarStatusReport>);
    fn sensor_lidar_msg__msg__LidarStatusReport__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LidarStatusReport>, out_seq: *mut rosidl_runtime_rs::Sequence<LidarStatusReport>) -> bool;
}

// Corresponds to sensor_lidar_msg__msg__LidarStatusReport
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarStatusReport {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_service_mode: super::super::msg::rmw::LidarMode,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LidarStatus>,

}



impl Default for LidarStatusReport {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !sensor_lidar_msg__msg__LidarStatusReport__init(&mut msg as *mut _) {
        panic!("Call to sensor_lidar_msg__msg__LidarStatusReport__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LidarStatusReport {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatusReport__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatusReport__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { sensor_lidar_msg__msg__LidarStatusReport__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LidarStatusReport {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LidarStatusReport where Self: Sized {
  const TYPE_NAME: &'static str = "sensor_lidar_msg/msg/LidarStatusReport";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__sensor_lidar_msg__msg__LidarStatusReport() }
  }
}


