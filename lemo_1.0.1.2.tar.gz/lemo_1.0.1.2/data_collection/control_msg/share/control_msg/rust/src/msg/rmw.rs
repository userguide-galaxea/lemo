#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "control_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__control_msg__msg__PlaceHolder() -> *const std::ffi::c_void;
}

#[link(name = "control_msg__rosidl_generator_c")]
extern "C" {
    fn control_msg__msg__PlaceHolder__init(msg: *mut PlaceHolder) -> bool;
    fn control_msg__msg__PlaceHolder__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PlaceHolder>, size: usize) -> bool;
    fn control_msg__msg__PlaceHolder__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PlaceHolder>);
    fn control_msg__msg__PlaceHolder__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PlaceHolder>, out_seq: *mut rosidl_runtime_rs::Sequence<PlaceHolder>) -> bool;
}

// Corresponds to control_msg__msg__PlaceHolder
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PlaceHolder {

    // This member is not documented.
    #[allow(missing_docs)]
    pub placeholder: f32,

}



impl Default for PlaceHolder {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !control_msg__msg__PlaceHolder__init(&mut msg as *mut _) {
        panic!("Call to control_msg__msg__PlaceHolder__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PlaceHolder {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { control_msg__msg__PlaceHolder__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { control_msg__msg__PlaceHolder__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { control_msg__msg__PlaceHolder__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PlaceHolder {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PlaceHolder where Self: Sized {
  const TYPE_NAME: &'static str = "control_msg/msg/PlaceHolder";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__control_msg__msg__PlaceHolder() }
  }
}


