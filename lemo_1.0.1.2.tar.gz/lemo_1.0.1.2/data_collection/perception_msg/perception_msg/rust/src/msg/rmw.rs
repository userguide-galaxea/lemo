#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__BarrierTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__BarrierTypeEnum__init(msg: *mut BarrierTypeEnum) -> bool;
    fn perception_msg__msg__BarrierTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BarrierTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__BarrierTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BarrierTypeEnum>);
    fn perception_msg__msg__BarrierTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BarrierTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<BarrierTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__BarrierTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BarrierTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for BarrierTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__BarrierTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__BarrierTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BarrierTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__BarrierTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__BarrierTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__BarrierTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BarrierTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BarrierTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/BarrierTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__BarrierTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__CameraModelEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__CameraModelEnum__init(msg: *mut CameraModelEnum) -> bool;
    fn perception_msg__msg__CameraModelEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CameraModelEnum>, size: usize) -> bool;
    fn perception_msg__msg__CameraModelEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CameraModelEnum>);
    fn perception_msg__msg__CameraModelEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CameraModelEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<CameraModelEnum>) -> bool;
}

// Corresponds to perception_msg__msg__CameraModelEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CameraModelEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for CameraModelEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__CameraModelEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__CameraModelEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CameraModelEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraModelEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraModelEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraModelEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CameraModelEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CameraModelEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/CameraModelEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__CameraModelEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__CameraSourceEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__CameraSourceEnum__init(msg: *mut CameraSourceEnum) -> bool;
    fn perception_msg__msg__CameraSourceEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CameraSourceEnum>, size: usize) -> bool;
    fn perception_msg__msg__CameraSourceEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CameraSourceEnum>);
    fn perception_msg__msg__CameraSourceEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CameraSourceEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<CameraSourceEnum>) -> bool;
}

// Corresponds to perception_msg__msg__CameraSourceEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CameraSourceEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for CameraSourceEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__CameraSourceEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__CameraSourceEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CameraSourceEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraSourceEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraSourceEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__CameraSourceEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CameraSourceEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CameraSourceEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/CameraSourceEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__CameraSourceEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FrameMeta() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__FrameMeta__init(msg: *mut FrameMeta) -> bool;
    fn perception_msg__msg__FrameMeta__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FrameMeta>, size: usize) -> bool;
    fn perception_msg__msg__FrameMeta__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FrameMeta>);
    fn perception_msg__msg__FrameMeta__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FrameMeta>, out_seq: *mut rosidl_runtime_rs::Sequence<FrameMeta>) -> bool;
}

// Corresponds to perception_msg__msg__FrameMeta
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FrameMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,

}



impl Default for FrameMeta {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__FrameMeta__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__FrameMeta__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FrameMeta {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FrameMeta__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FrameMeta__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FrameMeta__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FrameMeta {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FrameMeta where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/FrameMeta";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FrameMeta() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FusionObstaclePointType() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__FusionObstaclePointType__init(msg: *mut FusionObstaclePointType) -> bool;
    fn perception_msg__msg__FusionObstaclePointType__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FusionObstaclePointType>, size: usize) -> bool;
    fn perception_msg__msg__FusionObstaclePointType__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FusionObstaclePointType>);
    fn perception_msg__msg__FusionObstaclePointType__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FusionObstaclePointType>, out_seq: *mut rosidl_runtime_rs::Sequence<FusionObstaclePointType>) -> bool;
}

// Corresponds to perception_msg__msg__FusionObstaclePointType
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FusionObstaclePointType {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for FusionObstaclePointType {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__FusionObstaclePointType__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__FusionObstaclePointType__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FusionObstaclePointType {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstaclePointType__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstaclePointType__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstaclePointType__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FusionObstaclePointType {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FusionObstaclePointType where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/FusionObstaclePointType";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FusionObstaclePointType() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FusionObstacleTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__FusionObstacleTypeEnum__init(msg: *mut FusionObstacleTypeEnum) -> bool;
    fn perception_msg__msg__FusionObstacleTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FusionObstacleTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__FusionObstacleTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FusionObstacleTypeEnum>);
    fn perception_msg__msg__FusionObstacleTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FusionObstacleTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<FusionObstacleTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__FusionObstacleTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FusionObstacleTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for FusionObstacleTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__FusionObstacleTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__FusionObstacleTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FusionObstacleTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstacleTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstacleTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__FusionObstacleTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FusionObstacleTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FusionObstacleTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/FusionObstacleTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__FusionObstacleTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GeneralDescriptor() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GeneralDescriptor__init(msg: *mut GeneralDescriptor) -> bool;
    fn perception_msg__msg__GeneralDescriptor__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GeneralDescriptor>, size: usize) -> bool;
    fn perception_msg__msg__GeneralDescriptor__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GeneralDescriptor>);
    fn perception_msg__msg__GeneralDescriptor__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GeneralDescriptor>, out_seq: *mut rosidl_runtime_rs::Sequence<GeneralDescriptor>) -> bool;
}

// Corresponds to perception_msg__msg__GeneralDescriptor
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeneralDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::super::msg::rmw::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub global_descriptor_perception: super::super::msg::rmw::GlobalDescriptor,


    // This member is not documented.
    #[allow(missing_docs)]
    pub local_descriptor_perception: super::super::msg::rmw::LocalDescriptor,

}



impl Default for GeneralDescriptor {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GeneralDescriptor__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GeneralDescriptor__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GeneralDescriptor {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralDescriptor__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralDescriptor__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralDescriptor__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GeneralDescriptor {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GeneralDescriptor where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GeneralDescriptor";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GeneralDescriptor() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GeneralObjectTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GeneralObjectTypeEnum__init(msg: *mut GeneralObjectTypeEnum) -> bool;
    fn perception_msg__msg__GeneralObjectTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GeneralObjectTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__GeneralObjectTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GeneralObjectTypeEnum>);
    fn perception_msg__msg__GeneralObjectTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GeneralObjectTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<GeneralObjectTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__GeneralObjectTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeneralObjectTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GeneralObjectTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GeneralObjectTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GeneralObjectTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GeneralObjectTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralObjectTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralObjectTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GeneralObjectTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GeneralObjectTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GeneralObjectTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GeneralObjectTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GeneralObjectTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptor() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GlobalDescriptor__init(msg: *mut GlobalDescriptor) -> bool;
    fn perception_msg__msg__GlobalDescriptor__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptor>, size: usize) -> bool;
    fn perception_msg__msg__GlobalDescriptor__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptor>);
    fn perception_msg__msg__GlobalDescriptor__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GlobalDescriptor>, out_seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptor>) -> bool;
}

// Corresponds to perception_msg__msg__GlobalDescriptor
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::super::msg::rmw::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub global_descriptor: super::super::msg::rmw::GlobalDescriptorArray,

}



impl Default for GlobalDescriptor {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GlobalDescriptor__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GlobalDescriptor__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GlobalDescriptor {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptor__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptor__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptor__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptor {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GlobalDescriptor where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GlobalDescriptor";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptor() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptorArray() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GlobalDescriptorArray__init(msg: *mut GlobalDescriptorArray) -> bool;
    fn perception_msg__msg__GlobalDescriptorArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorArray>, size: usize) -> bool;
    fn perception_msg__msg__GlobalDescriptorArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorArray>);
    fn perception_msg__msg__GlobalDescriptorArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GlobalDescriptorArray>, out_seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorArray>) -> bool;
}

// Corresponds to perception_msg__msg__GlobalDescriptorArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptorArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feature_descriptor: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub log_info_2d: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_info: rosidl_runtime_rs::String,

}



impl Default for GlobalDescriptorArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GlobalDescriptorArray__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GlobalDescriptorArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GlobalDescriptorArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptorArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GlobalDescriptorArray where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GlobalDescriptorArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptorArray() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptorPropertyEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GlobalDescriptorPropertyEnum__init(msg: *mut GlobalDescriptorPropertyEnum) -> bool;
    fn perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorPropertyEnum>, size: usize) -> bool;
    fn perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorPropertyEnum>);
    fn perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GlobalDescriptorPropertyEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<GlobalDescriptorPropertyEnum>) -> bool;
}

// Corresponds to perception_msg__msg__GlobalDescriptorPropertyEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptorPropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GlobalDescriptorPropertyEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GlobalDescriptorPropertyEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GlobalDescriptorPropertyEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GlobalDescriptorPropertyEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GlobalDescriptorPropertyEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptorPropertyEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GlobalDescriptorPropertyEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GlobalDescriptorPropertyEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GlobalDescriptorPropertyEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid1f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Grid1f__init(msg: *mut Grid1f) -> bool;
    fn perception_msg__msg__Grid1f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Grid1f>, size: usize) -> bool;
    fn perception_msg__msg__Grid1f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Grid1f>);
    fn perception_msg__msg__Grid1f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Grid1f>, out_seq: *mut rosidl_runtime_rs::Sequence<Grid1f>) -> bool;
}

// Corresponds to perception_msg__msg__Grid1f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid1f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid1f: rosidl_runtime_rs::Sequence<f32>,

}



impl Default for Grid1f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Grid1f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Grid1f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Grid1f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid1f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid1f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid1f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Grid1f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Grid1f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Grid1f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid1f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid2f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Grid2f__init(msg: *mut Grid2f) -> bool;
    fn perception_msg__msg__Grid2f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Grid2f>, size: usize) -> bool;
    fn perception_msg__msg__Grid2f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Grid2f>);
    fn perception_msg__msg__Grid2f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Grid2f>, out_seq: *mut rosidl_runtime_rs::Sequence<Grid2f>) -> bool;
}

// Corresponds to perception_msg__msg__Grid2f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid2f: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Grid1f>,

}



impl Default for Grid2f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Grid2f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Grid2f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Grid2f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid2f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid2f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid2f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Grid2f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Grid2f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Grid2f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid2f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid3f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Grid3f__init(msg: *mut Grid3f) -> bool;
    fn perception_msg__msg__Grid3f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Grid3f>, size: usize) -> bool;
    fn perception_msg__msg__Grid3f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Grid3f>);
    fn perception_msg__msg__Grid3f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Grid3f>, out_seq: *mut rosidl_runtime_rs::Sequence<Grid3f>) -> bool;
}

// Corresponds to perception_msg__msg__Grid3f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid3f: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Grid2f>,

}



impl Default for Grid3f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Grid3f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Grid3f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Grid3f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid3f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid3f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Grid3f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Grid3f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Grid3f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Grid3f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Grid3f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GroundPerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GroundPerception__init(msg: *mut GroundPerception) -> bool;
    fn perception_msg__msg__GroundPerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GroundPerception>, size: usize) -> bool;
    fn perception_msg__msg__GroundPerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GroundPerception>);
    fn perception_msg__msg__GroundPerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GroundPerception>, out_seq: *mut rosidl_runtime_rs::Sequence<GroundPerception>) -> bool;
}

// Corresponds to perception_msg__msg__GroundPerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GroundPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_camera_exposure: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_preprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_before_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_postprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_model_result_publish: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_types: super::super::msg::rmw::VoxelGroundTypes,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_heights: super::super::msg::rmw::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_type_scores: super::super::msg::rmw::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for GroundPerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GroundPerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GroundPerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GroundPerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundPerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundPerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundPerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GroundPerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GroundPerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GroundPerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GroundPerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GroundTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__GroundTypeEnum__init(msg: *mut GroundTypeEnum) -> bool;
    fn perception_msg__msg__GroundTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GroundTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__GroundTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GroundTypeEnum>);
    fn perception_msg__msg__GroundTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GroundTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<GroundTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__GroundTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GroundTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GroundTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__GroundTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__GroundTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GroundTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__GroundTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GroundTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GroundTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/GroundTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__GroundTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Lane() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Lane__init(msg: *mut Lane) -> bool;
    fn perception_msg__msg__Lane__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Lane>, size: usize) -> bool;
    fn perception_msg__msg__Lane__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Lane>);
    fn perception_msg__msg__Lane__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Lane>, out_seq: *mut rosidl_runtime_rs::Sequence<Lane>) -> bool;
}

// Corresponds to perception_msg__msg__Lane
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Lane {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub index: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_x: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_y: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_v: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub coefficient_bv: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub coefficient_bv_sigma: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_failed_3d: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_type: super::super::msg::rmw::LaneTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_color: super::super::msg::rmw::LaneColorEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_width: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_centerline: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_x: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_y: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_z: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_horizontal_line: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_horizontal_type: super::super::msg::rmw::LaneHorizontalTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stopline_depth: f32,

}



impl Default for Lane {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Lane__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Lane__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Lane {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Lane__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Lane__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Lane__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Lane {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Lane where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Lane";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Lane() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneColorEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneColorEnum__init(msg: *mut LaneColorEnum) -> bool;
    fn perception_msg__msg__LaneColorEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneColorEnum>, size: usize) -> bool;
    fn perception_msg__msg__LaneColorEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneColorEnum>);
    fn perception_msg__msg__LaneColorEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneColorEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneColorEnum>) -> bool;
}

// Corresponds to perception_msg__msg__LaneColorEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneColorEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneColorEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneColorEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneColorEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneColorEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneColorEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneColorEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneColorEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneColorEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneColorEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneColorEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneColorEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneHorizontalTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneHorizontalTypeEnum__init(msg: *mut LaneHorizontalTypeEnum) -> bool;
    fn perception_msg__msg__LaneHorizontalTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneHorizontalTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__LaneHorizontalTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneHorizontalTypeEnum>);
    fn perception_msg__msg__LaneHorizontalTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneHorizontalTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneHorizontalTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__LaneHorizontalTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneHorizontalTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneHorizontalTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneHorizontalTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneHorizontalTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneHorizontalTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneHorizontalTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneHorizontalTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneHorizontalTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneHorizontalTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneHorizontalTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneHorizontalTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneHorizontalTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LanePerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LanePerception__init(msg: *mut LanePerception) -> bool;
    fn perception_msg__msg__LanePerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LanePerception>, size: usize) -> bool;
    fn perception_msg__msg__LanePerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LanePerception>);
    fn perception_msg__msg__LanePerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LanePerception>, out_seq: *mut rosidl_runtime_rs::Sequence<LanePerception>) -> bool;
}

// Corresponds to perception_msg__msg__LanePerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LanePerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lanes: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Lane>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for LanePerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LanePerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LanePerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LanePerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LanePerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LanePerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LanePerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LanePerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LanePerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LanePerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LanePerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegment() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneSegment__init(msg: *mut LaneSegment) -> bool;
    fn perception_msg__msg__LaneSegment__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneSegment>, size: usize) -> bool;
    fn perception_msg__msg__LaneSegment__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneSegment>);
    fn perception_msg__msg__LaneSegment__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneSegment>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneSegment>) -> bool;
}

// Corresponds to perception_msg__msg__LaneSegment
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegment {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Point2f>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Point3f>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_track_id: rosidl_runtime_rs::Sequence<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_score: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_type: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LaneSegmentPointEnum>,

}



impl Default for LaneSegment {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneSegment__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneSegment__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneSegment {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegment__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegment__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegment__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneSegment {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneSegment where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneSegment";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegment() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegmentPerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneSegmentPerception__init(msg: *mut LaneSegmentPerception) -> bool;
    fn perception_msg__msg__LaneSegmentPerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPerception>, size: usize) -> bool;
    fn perception_msg__msg__LaneSegmentPerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPerception>);
    fn perception_msg__msg__LaneSegmentPerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneSegmentPerception>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPerception>) -> bool;
}

// Corresponds to perception_msg__msg__LaneSegmentPerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegmentPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_segments: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LaneSegment>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for LaneSegmentPerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneSegmentPerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneSegmentPerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneSegmentPerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneSegmentPerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneSegmentPerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneSegmentPerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegmentPerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegmentPointEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneSegmentPointEnum__init(msg: *mut LaneSegmentPointEnum) -> bool;
    fn perception_msg__msg__LaneSegmentPointEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPointEnum>, size: usize) -> bool;
    fn perception_msg__msg__LaneSegmentPointEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPointEnum>);
    fn perception_msg__msg__LaneSegmentPointEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneSegmentPointEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneSegmentPointEnum>) -> bool;
}

// Corresponds to perception_msg__msg__LaneSegmentPointEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegmentPointEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneSegmentPointEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneSegmentPointEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneSegmentPointEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneSegmentPointEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPointEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPointEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneSegmentPointEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneSegmentPointEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneSegmentPointEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneSegmentPointEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneSegmentPointEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LaneTypeEnum__init(msg: *mut LaneTypeEnum) -> bool;
    fn perception_msg__msg__LaneTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LaneTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__LaneTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LaneTypeEnum>);
    fn perception_msg__msg__LaneTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LaneTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<LaneTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__LaneTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LaneTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LaneTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LaneTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LaneTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LaneTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LaneTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LaneTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LaneTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptor() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LocalDescriptor__init(msg: *mut LocalDescriptor) -> bool;
    fn perception_msg__msg__LocalDescriptor__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptor>, size: usize) -> bool;
    fn perception_msg__msg__LocalDescriptor__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptor>);
    fn perception_msg__msg__LocalDescriptor__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LocalDescriptor>, out_seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptor>) -> bool;
}

// Corresponds to perception_msg__msg__LocalDescriptor
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::super::msg::rmw::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub local_descriptor_arrays: rosidl_runtime_rs::Sequence<super::super::msg::rmw::LocalDescriptorArray>,

}



impl Default for LocalDescriptor {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LocalDescriptor__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LocalDescriptor__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LocalDescriptor {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptor__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptor__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptor__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptor {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LocalDescriptor where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LocalDescriptor";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptor() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptorArray() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LocalDescriptorArray__init(msg: *mut LocalDescriptorArray) -> bool;
    fn perception_msg__msg__LocalDescriptorArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArray>, size: usize) -> bool;
    fn perception_msg__msg__LocalDescriptorArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArray>);
    fn perception_msg__msg__LocalDescriptorArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LocalDescriptorArray>, out_seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArray>) -> bool;
}

// Corresponds to perception_msg__msg__LocalDescriptorArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptorArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_point: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_ids: rosidl_runtime_rs::Sequence<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub point_xs: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub point_ys: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub descriptor_size: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub descriptors: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub log_info_2d: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_info: rosidl_runtime_rs::String,

}



impl Default for LocalDescriptorArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LocalDescriptorArray__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LocalDescriptorArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LocalDescriptorArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptorArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LocalDescriptorArray where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LocalDescriptorArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptorArray() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptorArrayPropertyEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LocalDescriptorArrayPropertyEnum__init(msg: *mut LocalDescriptorArrayPropertyEnum) -> bool;
    fn perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArrayPropertyEnum>, size: usize) -> bool;
    fn perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArrayPropertyEnum>);
    fn perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LocalDescriptorArrayPropertyEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<LocalDescriptorArrayPropertyEnum>) -> bool;
}

// Corresponds to perception_msg__msg__LocalDescriptorArrayPropertyEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptorArrayPropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LocalDescriptorArrayPropertyEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LocalDescriptorArrayPropertyEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LocalDescriptorArrayPropertyEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LocalDescriptorArrayPropertyEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocalDescriptorArrayPropertyEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptorArrayPropertyEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LocalDescriptorArrayPropertyEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LocalDescriptorArrayPropertyEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocalDescriptorArrayPropertyEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocationInfo() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__LocationInfo__init(msg: *mut LocationInfo) -> bool;
    fn perception_msg__msg__LocationInfo__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LocationInfo>, size: usize) -> bool;
    fn perception_msg__msg__LocationInfo__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LocationInfo>);
    fn perception_msg__msg__LocationInfo__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LocationInfo>, out_seq: *mut rosidl_runtime_rs::Sequence<LocationInfo>) -> bool;
}

// Corresponds to perception_msg__msg__LocationInfo
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocationInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_valid: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qy: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qz: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub tx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ty: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub tz: f32,

}



impl Default for LocationInfo {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__LocationInfo__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__LocationInfo__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LocationInfo {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocationInfo__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocationInfo__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__LocationInfo__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LocationInfo {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LocationInfo where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/LocationInfo";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__LocationInfo() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Object() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Object__init(msg: *mut Object) -> bool;
    fn perception_msg__msg__Object__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Object>, size: usize) -> bool;
    fn perception_msg__msg__Object__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Object>);
    fn perception_msg__msg__Object__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Object>, out_seq: *mut rosidl_runtime_rs::Sequence<Object>) -> bool;
}

// Corresponds to perception_msg__msg__Object
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Object {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::super::msg::rmw::ObjectTypeInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility_2d: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bounding_box_2d: super::super::msg::rmw::Rect4f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_info: super::super::msg::rmw::ObjectTrackInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reid_feature: super::super::msg::rmw::ObjectReIdFeature,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape_3d: super::super::msg::rmw::Shape3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub heading_theta_bv: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity_bv: super::super::msg::rmw::Vector3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub location_bv: super::super::msg::rmw::Point3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ttc: f32,

}



impl Default for Object {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Object__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Object__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Object {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Object__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Object__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Object__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Object {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Object where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Object";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Object() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectPerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectPerception__init(msg: *mut ObjectPerception) -> bool;
    fn perception_msg__msg__ObjectPerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectPerception>, size: usize) -> bool;
    fn perception_msg__msg__ObjectPerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectPerception>);
    fn perception_msg__msg__ObjectPerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectPerception>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectPerception>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectPerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::super::msg::rmw::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub objects: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Object>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for ObjectPerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectPerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectPerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectPerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectPerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectPerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectPerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectPerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectPerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectPerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectPerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectReIdFeature() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectReIdFeature__init(msg: *mut ObjectReIdFeature) -> bool;
    fn perception_msg__msg__ObjectReIdFeature__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectReIdFeature>, size: usize) -> bool;
    fn perception_msg__msg__ObjectReIdFeature__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectReIdFeature>);
    fn perception_msg__msg__ObjectReIdFeature__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectReIdFeature>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectReIdFeature>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectReIdFeature
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectReIdFeature {

    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<f32>,

}



impl Default for ObjectReIdFeature {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectReIdFeature__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectReIdFeature__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectReIdFeature {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectReIdFeature__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectReIdFeature__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectReIdFeature__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectReIdFeature {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectReIdFeature where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectReIdFeature";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectReIdFeature() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTrackInfo() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectTrackInfo__init(msg: *mut ObjectTrackInfo) -> bool;
    fn perception_msg__msg__ObjectTrackInfo__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectTrackInfo>, size: usize) -> bool;
    fn perception_msg__msg__ObjectTrackInfo__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectTrackInfo>);
    fn perception_msg__msg__ObjectTrackInfo__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectTrackInfo>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectTrackInfo>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectTrackInfo
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTrackInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_times: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub age_in_seconds: f32,

}



impl Default for ObjectTrackInfo {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectTrackInfo__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectTrackInfo__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectTrackInfo {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTrackInfo__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTrackInfo__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTrackInfo__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectTrackInfo {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectTrackInfo where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectTrackInfo";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTrackInfo() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectTypeEnum__init(msg: *mut ObjectTypeEnum) -> bool;
    fn perception_msg__msg__ObjectTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__ObjectTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeEnum>);
    fn perception_msg__msg__ObjectTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for ObjectTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypeInfo() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectTypeInfo__init(msg: *mut ObjectTypeInfo) -> bool;
    fn perception_msg__msg__ObjectTypeInfo__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeInfo>, size: usize) -> bool;
    fn perception_msg__msg__ObjectTypeInfo__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeInfo>);
    fn perception_msg__msg__ObjectTypeInfo__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectTypeInfo>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectTypeInfo>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectTypeInfo
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypeInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub type_properties: rosidl_runtime_rs::Sequence<super::super::msg::rmw::ObjectTypePropertyEnum>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::super::msg::rmw::ObjectTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub general_object_type: super::super::msg::rmw::GeneralObjectTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vsu_type: super::super::msg::rmw::VsuTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vsu_sub_type: super::super::msg::rmw::VsuSubTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub barrier_type: super::super::msg::rmw::BarrierTypeEnum,

}



impl Default for ObjectTypeInfo {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectTypeInfo__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectTypeInfo__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectTypeInfo {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeInfo__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeInfo__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypeInfo__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectTypeInfo {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectTypeInfo where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectTypeInfo";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypeInfo() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypePropertyEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__ObjectTypePropertyEnum__init(msg: *mut ObjectTypePropertyEnum) -> bool;
    fn perception_msg__msg__ObjectTypePropertyEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypePropertyEnum>, size: usize) -> bool;
    fn perception_msg__msg__ObjectTypePropertyEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ObjectTypePropertyEnum>);
    fn perception_msg__msg__ObjectTypePropertyEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ObjectTypePropertyEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<ObjectTypePropertyEnum>) -> bool;
}

// Corresponds to perception_msg__msg__ObjectTypePropertyEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypePropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for ObjectTypePropertyEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__ObjectTypePropertyEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__ObjectTypePropertyEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ObjectTypePropertyEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypePropertyEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypePropertyEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__ObjectTypePropertyEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ObjectTypePropertyEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ObjectTypePropertyEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/ObjectTypePropertyEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__ObjectTypePropertyEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__OccupancyPerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__OccupancyPerception__init(msg: *mut OccupancyPerception) -> bool;
    fn perception_msg__msg__OccupancyPerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<OccupancyPerception>, size: usize) -> bool;
    fn perception_msg__msg__OccupancyPerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<OccupancyPerception>);
    fn perception_msg__msg__OccupancyPerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<OccupancyPerception>, out_seq: *mut rosidl_runtime_rs::Sequence<OccupancyPerception>) -> bool;
}

// Corresponds to perception_msg__msg__OccupancyPerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct OccupancyPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_camera_exposure: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_preprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_before_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_postprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_model_result_publish: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_states: super::super::msg::rmw::VoxelStates,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_state_scores: super::super::msg::rmw::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_types: super::super::msg::rmw::VoxelTypes,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_type_scores: super::super::msg::rmw::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for OccupancyPerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__OccupancyPerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__OccupancyPerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for OccupancyPerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__OccupancyPerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__OccupancyPerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__OccupancyPerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for OccupancyPerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for OccupancyPerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/OccupancyPerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__OccupancyPerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionObjectData() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PerceptionFusionObjectData__init(msg: *mut PerceptionFusionObjectData) -> bool;
    fn perception_msg__msg__PerceptionFusionObjectData__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectData>, size: usize) -> bool;
    fn perception_msg__msg__PerceptionFusionObjectData__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectData>);
    fn perception_msg__msg__PerceptionFusionObjectData__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PerceptionFusionObjectData>, out_seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectData>) -> bool;
}

// Corresponds to perception_msg__msg__PerceptionFusionObjectData
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionObjectData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::super::msg::rmw::ObjectTypeInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_static: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub static_confidence: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape: super::super::msg::rmw::Shape3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::super::msg::rmw::Point3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub acceleration: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub heading_yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub angular_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_position: super::super::msg::rmw::Point3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_velocity: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_acceleration: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_heading_yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_angular_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity_relative_to_ground: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub acceleration_relative_to_ground: super::super::msg::rmw::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub crash_risk_ttc: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub polygon_bottom: super::super::msg::rmw::Polygon3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub polygon_top: super::super::msg::rmw::Polygon3f,

}



impl Default for PerceptionFusionObjectData {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PerceptionFusionObjectData__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PerceptionFusionObjectData__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PerceptionFusionObjectData {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectData__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectData__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectData__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionObjectData {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PerceptionFusionObjectData where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PerceptionFusionObjectData";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionObjectData() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionObjectResult() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PerceptionFusionObjectResult__init(msg: *mut PerceptionFusionObjectResult) -> bool;
    fn perception_msg__msg__PerceptionFusionObjectResult__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectResult>, size: usize) -> bool;
    fn perception_msg__msg__PerceptionFusionObjectResult__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectResult>);
    fn perception_msg__msg__PerceptionFusionObjectResult__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PerceptionFusionObjectResult>, out_seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionObjectResult>) -> bool;
}

// Corresponds to perception_msg__msg__PerceptionFusionObjectResult
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionObjectResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::super::msg::rmw::PerceptionFusionResultMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub perception_fusion_objects_data: rosidl_runtime_rs::Sequence<super::super::msg::rmw::PerceptionFusionObjectData>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for PerceptionFusionObjectResult {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PerceptionFusionObjectResult__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PerceptionFusionObjectResult__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PerceptionFusionObjectResult {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectResult__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectResult__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionObjectResult__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionObjectResult {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PerceptionFusionObjectResult where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PerceptionFusionObjectResult";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionObjectResult() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionResultMeta() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PerceptionFusionResultMeta__init(msg: *mut PerceptionFusionResultMeta) -> bool;
    fn perception_msg__msg__PerceptionFusionResultMeta__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionResultMeta>, size: usize) -> bool;
    fn perception_msg__msg__PerceptionFusionResultMeta__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionResultMeta>);
    fn perception_msg__msg__PerceptionFusionResultMeta__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PerceptionFusionResultMeta>, out_seq: *mut rosidl_runtime_rs::Sequence<PerceptionFusionResultMeta>) -> bool;
}

// Corresponds to perception_msg__msg__PerceptionFusionResultMeta
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionResultMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_start_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_finish_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version_tag: rosidl_runtime_rs::String,

}



impl Default for PerceptionFusionResultMeta {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PerceptionFusionResultMeta__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PerceptionFusionResultMeta__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PerceptionFusionResultMeta {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionResultMeta__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionResultMeta__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionFusionResultMeta__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionResultMeta {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PerceptionFusionResultMeta where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PerceptionFusionResultMeta";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionFusionResultMeta() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionMeta() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PerceptionMeta__init(msg: *mut PerceptionMeta) -> bool;
    fn perception_msg__msg__PerceptionMeta__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PerceptionMeta>, size: usize) -> bool;
    fn perception_msg__msg__PerceptionMeta__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PerceptionMeta>);
    fn perception_msg__msg__PerceptionMeta__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PerceptionMeta>, out_seq: *mut rosidl_runtime_rs::Sequence<PerceptionMeta>) -> bool;
}

// Corresponds to perception_msg__msg__PerceptionMeta
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub algorithm_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub instance_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_start_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_finish_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relevant_frames: rosidl_runtime_rs::Sequence<super::super::msg::rmw::FrameMeta>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version_tag: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ts_log: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_tag: rosidl_runtime_rs::String,

}



impl Default for PerceptionMeta {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PerceptionMeta__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PerceptionMeta__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PerceptionMeta {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionMeta__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionMeta__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PerceptionMeta__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PerceptionMeta {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PerceptionMeta where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PerceptionMeta";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PerceptionMeta() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point2d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Point2d__init(msg: *mut Point2d) -> bool;
    fn perception_msg__msg__Point2d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Point2d>, size: usize) -> bool;
    fn perception_msg__msg__Point2d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Point2d>);
    fn perception_msg__msg__Point2d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Point2d>, out_seq: *mut rosidl_runtime_rs::Sequence<Point2d>) -> bool;
}

// Corresponds to perception_msg__msg__Point2d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,

}



impl Default for Point2d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Point2d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Point2d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Point2d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Point2d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Point2d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Point2d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point2d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point2f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Point2f__init(msg: *mut Point2f) -> bool;
    fn perception_msg__msg__Point2f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Point2f>, size: usize) -> bool;
    fn perception_msg__msg__Point2f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Point2f>);
    fn perception_msg__msg__Point2f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Point2f>, out_seq: *mut rosidl_runtime_rs::Sequence<Point2f>) -> bool;
}

// Corresponds to perception_msg__msg__Point2f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,

}



impl Default for Point2f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Point2f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Point2f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Point2f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point2f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Point2f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Point2f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Point2f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point2f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point3d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Point3d__init(msg: *mut Point3d) -> bool;
    fn perception_msg__msg__Point3d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Point3d>, size: usize) -> bool;
    fn perception_msg__msg__Point3d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Point3d>);
    fn perception_msg__msg__Point3d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Point3d>, out_seq: *mut rosidl_runtime_rs::Sequence<Point3d>) -> bool;
}

// Corresponds to perception_msg__msg__Point3d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f64,

}



impl Default for Point3d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Point3d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Point3d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Point3d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Point3d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Point3d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Point3d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point3d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point3f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Point3f__init(msg: *mut Point3f) -> bool;
    fn perception_msg__msg__Point3f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Point3f>, size: usize) -> bool;
    fn perception_msg__msg__Point3f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Point3f>);
    fn perception_msg__msg__Point3f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Point3f>, out_seq: *mut rosidl_runtime_rs::Sequence<Point3f>) -> bool;
}

// Corresponds to perception_msg__msg__Point3f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,

}



impl Default for Point3f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Point3f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Point3f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Point3f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Point3f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Point3f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Point3f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Point3f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Point3f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLine() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PoleLine__init(msg: *mut PoleLine) -> bool;
    fn perception_msg__msg__PoleLine__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PoleLine>, size: usize) -> bool;
    fn perception_msg__msg__PoleLine__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PoleLine>);
    fn perception_msg__msg__PoleLine__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PoleLine>, out_seq: *mut rosidl_runtime_rs::Sequence<PoleLine>) -> bool;
}

// Corresponds to perception_msg__msg__PoleLine
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLine {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: rosidl_runtime_rs::Sequence<super::super::msg::rmw::PoleLinePoint>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::super::msg::rmw::PoleLineTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,

}



impl Default for PoleLine {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PoleLine__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PoleLine__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PoleLine {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLine__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLine__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLine__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PoleLine {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PoleLine where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PoleLine";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLine() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLinePerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PoleLinePerception__init(msg: *mut PoleLinePerception) -> bool;
    fn perception_msg__msg__PoleLinePerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PoleLinePerception>, size: usize) -> bool;
    fn perception_msg__msg__PoleLinePerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PoleLinePerception>);
    fn perception_msg__msg__PoleLinePerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PoleLinePerception>, out_seq: *mut rosidl_runtime_rs::Sequence<PoleLinePerception>) -> bool;
}

// Corresponds to perception_msg__msg__PoleLinePerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLinePerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pole_lines: rosidl_runtime_rs::Sequence<super::super::msg::rmw::PoleLine>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for PoleLinePerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PoleLinePerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PoleLinePerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PoleLinePerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PoleLinePerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PoleLinePerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PoleLinePerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLinePerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLinePoint() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PoleLinePoint__init(msg: *mut PoleLinePoint) -> bool;
    fn perception_msg__msg__PoleLinePoint__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PoleLinePoint>, size: usize) -> bool;
    fn perception_msg__msg__PoleLinePoint__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PoleLinePoint>);
    fn perception_msg__msg__PoleLinePoint__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PoleLinePoint>, out_seq: *mut rosidl_runtime_rs::Sequence<PoleLinePoint>) -> bool;
}

// Corresponds to perception_msg__msg__PoleLinePoint
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLinePoint {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::super::msg::rmw::Point2f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility: f32,

}



impl Default for PoleLinePoint {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PoleLinePoint__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PoleLinePoint__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PoleLinePoint {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePoint__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePoint__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLinePoint__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PoleLinePoint {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PoleLinePoint where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PoleLinePoint";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLinePoint() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLineTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__PoleLineTypeEnum__init(msg: *mut PoleLineTypeEnum) -> bool;
    fn perception_msg__msg__PoleLineTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PoleLineTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__PoleLineTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PoleLineTypeEnum>);
    fn perception_msg__msg__PoleLineTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PoleLineTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<PoleLineTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__PoleLineTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLineTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for PoleLineTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__PoleLineTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__PoleLineTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PoleLineTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLineTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLineTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__PoleLineTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PoleLineTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PoleLineTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/PoleLineTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__PoleLineTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Polygon3d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Polygon3d__init(msg: *mut Polygon3d) -> bool;
    fn perception_msg__msg__Polygon3d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Polygon3d>, size: usize) -> bool;
    fn perception_msg__msg__Polygon3d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Polygon3d>);
    fn perception_msg__msg__Polygon3d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Polygon3d>, out_seq: *mut rosidl_runtime_rs::Sequence<Polygon3d>) -> bool;
}

// Corresponds to perception_msg__msg__Polygon3d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Polygon3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub points: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Point3d>,

}



impl Default for Polygon3d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Polygon3d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Polygon3d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Polygon3d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Polygon3d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Polygon3d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Polygon3d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Polygon3d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Polygon3f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Polygon3f__init(msg: *mut Polygon3f) -> bool;
    fn perception_msg__msg__Polygon3f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Polygon3f>, size: usize) -> bool;
    fn perception_msg__msg__Polygon3f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Polygon3f>);
    fn perception_msg__msg__Polygon3f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Polygon3f>, out_seq: *mut rosidl_runtime_rs::Sequence<Polygon3f>) -> bool;
}

// Corresponds to perception_msg__msg__Polygon3f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Polygon3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub points: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Point3f>,

}



impl Default for Polygon3f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Polygon3f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Polygon3f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Polygon3f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Polygon3f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Polygon3f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Polygon3f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Polygon3f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Polygon3f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Rect4d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Rect4d__init(msg: *mut Rect4d) -> bool;
    fn perception_msg__msg__Rect4d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Rect4d>, size: usize) -> bool;
    fn perception_msg__msg__Rect4d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Rect4d>);
    fn perception_msg__msg__Rect4d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Rect4d>, out_seq: *mut rosidl_runtime_rs::Sequence<Rect4d>) -> bool;
}

// Corresponds to perception_msg__msg__Rect4d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Rect4d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub left: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub top: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: f64,

}



impl Default for Rect4d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Rect4d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Rect4d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Rect4d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Rect4d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Rect4d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Rect4d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Rect4d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Rect4f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Rect4f__init(msg: *mut Rect4f) -> bool;
    fn perception_msg__msg__Rect4f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Rect4f>, size: usize) -> bool;
    fn perception_msg__msg__Rect4f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Rect4f>);
    fn perception_msg__msg__Rect4f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Rect4f>, out_seq: *mut rosidl_runtime_rs::Sequence<Rect4f>) -> bool;
}

// Corresponds to perception_msg__msg__Rect4f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Rect4f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub left: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub top: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: f32,

}



impl Default for Rect4f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Rect4f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Rect4f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Rect4f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Rect4f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Rect4f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Rect4f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Rect4f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Rect4f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape2d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Shape2d__init(msg: *mut Shape2d) -> bool;
    fn perception_msg__msg__Shape2d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Shape2d>, size: usize) -> bool;
    fn perception_msg__msg__Shape2d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Shape2d>);
    fn perception_msg__msg__Shape2d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Shape2d>, out_seq: *mut rosidl_runtime_rs::Sequence<Shape2d>) -> bool;
}

// Corresponds to perception_msg__msg__Shape2d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape2d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Shape2d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Shape2d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Shape2d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Shape2d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Shape2d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Shape2d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape2d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape2f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Shape2f__init(msg: *mut Shape2f) -> bool;
    fn perception_msg__msg__Shape2f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Shape2f>, size: usize) -> bool;
    fn perception_msg__msg__Shape2f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Shape2f>);
    fn perception_msg__msg__Shape2f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Shape2f>, out_seq: *mut rosidl_runtime_rs::Sequence<Shape2f>) -> bool;
}

// Corresponds to perception_msg__msg__Shape2f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f32,

}



impl Default for Shape2f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Shape2f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Shape2f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Shape2f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape2f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Shape2f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Shape2f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Shape2f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape2f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape3d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Shape3d__init(msg: *mut Shape3d) -> bool;
    fn perception_msg__msg__Shape3d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Shape3d>, size: usize) -> bool;
    fn perception_msg__msg__Shape3d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Shape3d>);
    fn perception_msg__msg__Shape3d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Shape3d>, out_seq: *mut rosidl_runtime_rs::Sequence<Shape3d>) -> bool;
}

// Corresponds to perception_msg__msg__Shape3d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape3d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Shape3d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Shape3d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Shape3d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Shape3d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Shape3d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Shape3d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape3d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape3f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Shape3f__init(msg: *mut Shape3f) -> bool;
    fn perception_msg__msg__Shape3f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Shape3f>, size: usize) -> bool;
    fn perception_msg__msg__Shape3f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Shape3f>);
    fn perception_msg__msg__Shape3f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Shape3f>, out_seq: *mut rosidl_runtime_rs::Sequence<Shape3f>) -> bool;
}

// Corresponds to perception_msg__msg__Shape3f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape3f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Shape3f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Shape3f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Shape3f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Shape3f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Shape3f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Shape3f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Shape3f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Shape3f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Sign() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Sign__init(msg: *mut Sign) -> bool;
    fn perception_msg__msg__Sign__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Sign>, size: usize) -> bool;
    fn perception_msg__msg__Sign__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Sign>);
    fn perception_msg__msg__Sign__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Sign>, out_seq: *mut rosidl_runtime_rs::Sequence<Sign>) -> bool;
}

// Corresponds to perception_msg__msg__Sign
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Sign {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::super::msg::rmw::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::super::msg::rmw::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: rosidl_runtime_rs::Sequence<super::super::msg::rmw::SignPoint>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape_info: super::super::msg::rmw::SignShapeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bounding_box_2d: super::super::msg::rmw::Rect4f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::super::msg::rmw::SignTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_multi_cam: bool,

}



impl Default for Sign {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Sign__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Sign__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Sign {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Sign__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Sign__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Sign__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Sign {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Sign where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Sign";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Sign() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignPerception() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__SignPerception__init(msg: *mut SignPerception) -> bool;
    fn perception_msg__msg__SignPerception__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SignPerception>, size: usize) -> bool;
    fn perception_msg__msg__SignPerception__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SignPerception>);
    fn perception_msg__msg__SignPerception__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SignPerception>, out_seq: *mut rosidl_runtime_rs::Sequence<SignPerception>) -> bool;
}

// Corresponds to perception_msg__msg__SignPerception
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub signs: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Sign>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for SignPerception {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__SignPerception__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__SignPerception__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SignPerception {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPerception__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPerception__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPerception__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SignPerception {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SignPerception where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/SignPerception";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignPerception() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignPoint() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__SignPoint__init(msg: *mut SignPoint) -> bool;
    fn perception_msg__msg__SignPoint__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SignPoint>, size: usize) -> bool;
    fn perception_msg__msg__SignPoint__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SignPoint>);
    fn perception_msg__msg__SignPoint__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SignPoint>, out_seq: *mut rosidl_runtime_rs::Sequence<SignPoint>) -> bool;
}

// Corresponds to perception_msg__msg__SignPoint
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignPoint {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::super::msg::rmw::Point2f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility: f32,

}



impl Default for SignPoint {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__SignPoint__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__SignPoint__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SignPoint {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPoint__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPoint__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignPoint__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SignPoint {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SignPoint where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/SignPoint";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignPoint() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignShapeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__SignShapeEnum__init(msg: *mut SignShapeEnum) -> bool;
    fn perception_msg__msg__SignShapeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SignShapeEnum>, size: usize) -> bool;
    fn perception_msg__msg__SignShapeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SignShapeEnum>);
    fn perception_msg__msg__SignShapeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SignShapeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<SignShapeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__SignShapeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignShapeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for SignShapeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__SignShapeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__SignShapeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SignShapeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignShapeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignShapeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignShapeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SignShapeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SignShapeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/SignShapeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignShapeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__SignTypeEnum__init(msg: *mut SignTypeEnum) -> bool;
    fn perception_msg__msg__SignTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SignTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__SignTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SignTypeEnum>);
    fn perception_msg__msg__SignTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SignTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<SignTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__SignTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for SignTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__SignTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__SignTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SignTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__SignTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SignTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SignTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/SignTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__SignTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector2d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Vector2d__init(msg: *mut Vector2d) -> bool;
    fn perception_msg__msg__Vector2d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Vector2d>, size: usize) -> bool;
    fn perception_msg__msg__Vector2d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Vector2d>);
    fn perception_msg__msg__Vector2d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Vector2d>, out_seq: *mut rosidl_runtime_rs::Sequence<Vector2d>) -> bool;
}

// Corresponds to perception_msg__msg__Vector2d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,

}



impl Default for Vector2d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Vector2d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Vector2d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Vector2d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Vector2d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Vector2d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Vector2d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector2d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector2f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Vector2f__init(msg: *mut Vector2f) -> bool;
    fn perception_msg__msg__Vector2f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Vector2f>, size: usize) -> bool;
    fn perception_msg__msg__Vector2f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Vector2f>);
    fn perception_msg__msg__Vector2f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Vector2f>, out_seq: *mut rosidl_runtime_rs::Sequence<Vector2f>) -> bool;
}

// Corresponds to perception_msg__msg__Vector2f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,

}



impl Default for Vector2f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Vector2f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Vector2f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Vector2f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector2f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Vector2f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Vector2f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Vector2f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector2f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector3d() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Vector3d__init(msg: *mut Vector3d) -> bool;
    fn perception_msg__msg__Vector3d__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Vector3d>, size: usize) -> bool;
    fn perception_msg__msg__Vector3d__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Vector3d>);
    fn perception_msg__msg__Vector3d__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Vector3d>, out_seq: *mut rosidl_runtime_rs::Sequence<Vector3d>) -> bool;
}

// Corresponds to perception_msg__msg__Vector3d
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f64,

}



impl Default for Vector3d {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Vector3d__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Vector3d__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Vector3d {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3d__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3d__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3d__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Vector3d {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Vector3d where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Vector3d";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector3d() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector3f() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__Vector3f__init(msg: *mut Vector3f) -> bool;
    fn perception_msg__msg__Vector3f__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Vector3f>, size: usize) -> bool;
    fn perception_msg__msg__Vector3f__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Vector3f>);
    fn perception_msg__msg__Vector3f__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Vector3f>, out_seq: *mut rosidl_runtime_rs::Sequence<Vector3f>) -> bool;
}

// Corresponds to perception_msg__msg__Vector3f
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,

}



impl Default for Vector3f {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__Vector3f__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__Vector3f__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Vector3f {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3f__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3f__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__Vector3f__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Vector3f {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Vector3f where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/Vector3f";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__Vector3f() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelGroundTypes() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__VoxelGroundTypes__init(msg: *mut VoxelGroundTypes) -> bool;
    fn perception_msg__msg__VoxelGroundTypes__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VoxelGroundTypes>, size: usize) -> bool;
    fn perception_msg__msg__VoxelGroundTypes__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VoxelGroundTypes>);
    fn perception_msg__msg__VoxelGroundTypes__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VoxelGroundTypes>, out_seq: *mut rosidl_runtime_rs::Sequence<VoxelGroundTypes>) -> bool;
}

// Corresponds to perception_msg__msg__VoxelGroundTypes
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelGroundTypes {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_ground_type: rosidl_runtime_rs::Sequence<super::super::msg::rmw::GroundTypeEnum>,

}



impl Default for VoxelGroundTypes {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__VoxelGroundTypes__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__VoxelGroundTypes__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VoxelGroundTypes {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelGroundTypes__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelGroundTypes__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelGroundTypes__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VoxelGroundTypes {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VoxelGroundTypes where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/VoxelGroundTypes";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelGroundTypes() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelStates() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__VoxelStates__init(msg: *mut VoxelStates) -> bool;
    fn perception_msg__msg__VoxelStates__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VoxelStates>, size: usize) -> bool;
    fn perception_msg__msg__VoxelStates__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VoxelStates>);
    fn perception_msg__msg__VoxelStates__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VoxelStates>, out_seq: *mut rosidl_runtime_rs::Sequence<VoxelStates>) -> bool;
}

// Corresponds to perception_msg__msg__VoxelStates
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelStates {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_states: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for VoxelStates {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__VoxelStates__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__VoxelStates__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VoxelStates {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelStates__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelStates__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelStates__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VoxelStates {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VoxelStates where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/VoxelStates";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelStates() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelTypes() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__VoxelTypes__init(msg: *mut VoxelTypes) -> bool;
    fn perception_msg__msg__VoxelTypes__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VoxelTypes>, size: usize) -> bool;
    fn perception_msg__msg__VoxelTypes__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VoxelTypes>);
    fn perception_msg__msg__VoxelTypes__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VoxelTypes>, out_seq: *mut rosidl_runtime_rs::Sequence<VoxelTypes>) -> bool;
}

// Corresponds to perception_msg__msg__VoxelTypes
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelTypes {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_types: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for VoxelTypes {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__VoxelTypes__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__VoxelTypes__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VoxelTypes {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelTypes__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelTypes__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VoxelTypes__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VoxelTypes {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VoxelTypes where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/VoxelTypes";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VoxelTypes() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VsuSubTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__VsuSubTypeEnum__init(msg: *mut VsuSubTypeEnum) -> bool;
    fn perception_msg__msg__VsuSubTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VsuSubTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__VsuSubTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VsuSubTypeEnum>);
    fn perception_msg__msg__VsuSubTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VsuSubTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<VsuSubTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__VsuSubTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VsuSubTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for VsuSubTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__VsuSubTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__VsuSubTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VsuSubTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuSubTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuSubTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuSubTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VsuSubTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VsuSubTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/VsuSubTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VsuSubTypeEnum() }
  }
}


#[link(name = "perception_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VsuTypeEnum() -> *const std::ffi::c_void;
}

#[link(name = "perception_msg__rosidl_generator_c")]
extern "C" {
    fn perception_msg__msg__VsuTypeEnum__init(msg: *mut VsuTypeEnum) -> bool;
    fn perception_msg__msg__VsuTypeEnum__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VsuTypeEnum>, size: usize) -> bool;
    fn perception_msg__msg__VsuTypeEnum__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VsuTypeEnum>);
    fn perception_msg__msg__VsuTypeEnum__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VsuTypeEnum>, out_seq: *mut rosidl_runtime_rs::Sequence<VsuTypeEnum>) -> bool;
}

// Corresponds to perception_msg__msg__VsuTypeEnum
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VsuTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for VsuTypeEnum {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !perception_msg__msg__VsuTypeEnum__init(&mut msg as *mut _) {
        panic!("Call to perception_msg__msg__VsuTypeEnum__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VsuTypeEnum {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuTypeEnum__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuTypeEnum__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { perception_msg__msg__VsuTypeEnum__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VsuTypeEnum {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VsuTypeEnum where Self: Sized {
  const TYPE_NAME: &'static str = "perception_msg/msg/VsuTypeEnum";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__perception_msg__msg__VsuTypeEnum() }
  }
}


