# generated from rosidl_generator_py/resource/_idl.py.em
# with input from sensor_lidar_msg:msg/LidarError.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LidarError(type):
    """Metaclass of message 'LidarError'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('sensor_lidar_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'sensor_lidar_msg.msg.LidarError')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lidar_error
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lidar_error
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lidar_error
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lidar_error
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lidar_error

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LidarError(metaclass=Metaclass_LidarError):
    """Message class 'LidarError'."""

    __slots__ = [
        '_mems_initialization_err',
        '_mems_operating_err',
        '_lidar_transmitting_err',
        '_lidar_receiving_err',
        '_lidar_fusa_err',
        '_window_contamination_err',
        '_sun_blind_err',
        '_window_heating_err',
        '_lidar_internal_err',
        '_lidar_external_err',
        '_lidar_internal_volt_err',
        '_lidar_temp_err',
        '_clock_err',
        '_sync_err',
        '_reserved1',
        '_reserved2',
    ]

    _fields_and_field_types = {
        'mems_initialization_err': 'uint8',
        'mems_operating_err': 'uint8',
        'lidar_transmitting_err': 'uint8',
        'lidar_receiving_err': 'uint8',
        'lidar_fusa_err': 'uint8',
        'window_contamination_err': 'uint8',
        'sun_blind_err': 'uint8',
        'window_heating_err': 'uint8',
        'lidar_internal_err': 'uint8',
        'lidar_external_err': 'uint8',
        'lidar_internal_volt_err': 'uint8',
        'lidar_temp_err': 'uint32',
        'clock_err': 'uint8',
        'sync_err': 'uint8',
        'reserved1': 'uint8',
        'reserved2': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.mems_initialization_err = kwargs.get('mems_initialization_err', int())
        self.mems_operating_err = kwargs.get('mems_operating_err', int())
        self.lidar_transmitting_err = kwargs.get('lidar_transmitting_err', int())
        self.lidar_receiving_err = kwargs.get('lidar_receiving_err', int())
        self.lidar_fusa_err = kwargs.get('lidar_fusa_err', int())
        self.window_contamination_err = kwargs.get('window_contamination_err', int())
        self.sun_blind_err = kwargs.get('sun_blind_err', int())
        self.window_heating_err = kwargs.get('window_heating_err', int())
        self.lidar_internal_err = kwargs.get('lidar_internal_err', int())
        self.lidar_external_err = kwargs.get('lidar_external_err', int())
        self.lidar_internal_volt_err = kwargs.get('lidar_internal_volt_err', int())
        self.lidar_temp_err = kwargs.get('lidar_temp_err', int())
        self.clock_err = kwargs.get('clock_err', int())
        self.sync_err = kwargs.get('sync_err', int())
        self.reserved1 = kwargs.get('reserved1', int())
        self.reserved2 = kwargs.get('reserved2', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.mems_initialization_err != other.mems_initialization_err:
            return False
        if self.mems_operating_err != other.mems_operating_err:
            return False
        if self.lidar_transmitting_err != other.lidar_transmitting_err:
            return False
        if self.lidar_receiving_err != other.lidar_receiving_err:
            return False
        if self.lidar_fusa_err != other.lidar_fusa_err:
            return False
        if self.window_contamination_err != other.window_contamination_err:
            return False
        if self.sun_blind_err != other.sun_blind_err:
            return False
        if self.window_heating_err != other.window_heating_err:
            return False
        if self.lidar_internal_err != other.lidar_internal_err:
            return False
        if self.lidar_external_err != other.lidar_external_err:
            return False
        if self.lidar_internal_volt_err != other.lidar_internal_volt_err:
            return False
        if self.lidar_temp_err != other.lidar_temp_err:
            return False
        if self.clock_err != other.clock_err:
            return False
        if self.sync_err != other.sync_err:
            return False
        if self.reserved1 != other.reserved1:
            return False
        if self.reserved2 != other.reserved2:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def mems_initialization_err(self):
        """Message field 'mems_initialization_err'."""
        return self._mems_initialization_err

    @mems_initialization_err.setter
    def mems_initialization_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'mems_initialization_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'mems_initialization_err' field must be an unsigned integer in [0, 255]"
        self._mems_initialization_err = value

    @builtins.property
    def mems_operating_err(self):
        """Message field 'mems_operating_err'."""
        return self._mems_operating_err

    @mems_operating_err.setter
    def mems_operating_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'mems_operating_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'mems_operating_err' field must be an unsigned integer in [0, 255]"
        self._mems_operating_err = value

    @builtins.property
    def lidar_transmitting_err(self):
        """Message field 'lidar_transmitting_err'."""
        return self._lidar_transmitting_err

    @lidar_transmitting_err.setter
    def lidar_transmitting_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_transmitting_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_transmitting_err' field must be an unsigned integer in [0, 255]"
        self._lidar_transmitting_err = value

    @builtins.property
    def lidar_receiving_err(self):
        """Message field 'lidar_receiving_err'."""
        return self._lidar_receiving_err

    @lidar_receiving_err.setter
    def lidar_receiving_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_receiving_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_receiving_err' field must be an unsigned integer in [0, 255]"
        self._lidar_receiving_err = value

    @builtins.property
    def lidar_fusa_err(self):
        """Message field 'lidar_fusa_err'."""
        return self._lidar_fusa_err

    @lidar_fusa_err.setter
    def lidar_fusa_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_fusa_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_fusa_err' field must be an unsigned integer in [0, 255]"
        self._lidar_fusa_err = value

    @builtins.property
    def window_contamination_err(self):
        """Message field 'window_contamination_err'."""
        return self._window_contamination_err

    @window_contamination_err.setter
    def window_contamination_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'window_contamination_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'window_contamination_err' field must be an unsigned integer in [0, 255]"
        self._window_contamination_err = value

    @builtins.property
    def sun_blind_err(self):
        """Message field 'sun_blind_err'."""
        return self._sun_blind_err

    @sun_blind_err.setter
    def sun_blind_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'sun_blind_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'sun_blind_err' field must be an unsigned integer in [0, 255]"
        self._sun_blind_err = value

    @builtins.property
    def window_heating_err(self):
        """Message field 'window_heating_err'."""
        return self._window_heating_err

    @window_heating_err.setter
    def window_heating_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'window_heating_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'window_heating_err' field must be an unsigned integer in [0, 255]"
        self._window_heating_err = value

    @builtins.property
    def lidar_internal_err(self):
        """Message field 'lidar_internal_err'."""
        return self._lidar_internal_err

    @lidar_internal_err.setter
    def lidar_internal_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_internal_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_internal_err' field must be an unsigned integer in [0, 255]"
        self._lidar_internal_err = value

    @builtins.property
    def lidar_external_err(self):
        """Message field 'lidar_external_err'."""
        return self._lidar_external_err

    @lidar_external_err.setter
    def lidar_external_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_external_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_external_err' field must be an unsigned integer in [0, 255]"
        self._lidar_external_err = value

    @builtins.property
    def lidar_internal_volt_err(self):
        """Message field 'lidar_internal_volt_err'."""
        return self._lidar_internal_volt_err

    @lidar_internal_volt_err.setter
    def lidar_internal_volt_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_internal_volt_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'lidar_internal_volt_err' field must be an unsigned integer in [0, 255]"
        self._lidar_internal_volt_err = value

    @builtins.property
    def lidar_temp_err(self):
        """Message field 'lidar_temp_err'."""
        return self._lidar_temp_err

    @lidar_temp_err.setter
    def lidar_temp_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lidar_temp_err' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'lidar_temp_err' field must be an unsigned integer in [0, 4294967295]"
        self._lidar_temp_err = value

    @builtins.property
    def clock_err(self):
        """Message field 'clock_err'."""
        return self._clock_err

    @clock_err.setter
    def clock_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'clock_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'clock_err' field must be an unsigned integer in [0, 255]"
        self._clock_err = value

    @builtins.property
    def sync_err(self):
        """Message field 'sync_err'."""
        return self._sync_err

    @sync_err.setter
    def sync_err(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'sync_err' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'sync_err' field must be an unsigned integer in [0, 255]"
        self._sync_err = value

    @builtins.property
    def reserved1(self):
        """Message field 'reserved1'."""
        return self._reserved1

    @reserved1.setter
    def reserved1(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'reserved1' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'reserved1' field must be an unsigned integer in [0, 255]"
        self._reserved1 = value

    @builtins.property
    def reserved2(self):
        """Message field 'reserved2'."""
        return self._reserved2

    @reserved2.setter
    def reserved2(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'reserved2' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'reserved2' field must be an unsigned integer in [0, 255]"
        self._reserved2 = value
