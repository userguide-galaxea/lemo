#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to perception_msg__msg__BarrierTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BarrierTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for BarrierTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BarrierTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for BarrierTypeEnum {
  type RmwMsg = super::msg::rmw::BarrierTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__CameraModelEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CameraModelEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for CameraModelEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CameraModelEnum::default())
  }
}

impl rosidl_runtime_rs::Message for CameraModelEnum {
  type RmwMsg = super::msg::rmw::CameraModelEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__CameraSourceEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CameraSourceEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for CameraSourceEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CameraSourceEnum::default())
  }
}

impl rosidl_runtime_rs::Message for CameraSourceEnum {
  type RmwMsg = super::msg::rmw::CameraSourceEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__FrameMeta

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FrameMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,

}



impl Default for FrameMeta {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::FrameMeta::default())
  }
}

impl rosidl_runtime_rs::Message for FrameMeta {
  type RmwMsg = super::msg::rmw::FrameMeta;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        timestamp_us: msg.timestamp_us,
        sequence: msg.sequence,
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      timestamp_us: msg.timestamp_us,
      sequence: msg.sequence,
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      timestamp_us: msg.timestamp_us,
      sequence: msg.sequence,
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
    }
  }
}


// Corresponds to perception_msg__msg__FusionObstaclePointType

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FusionObstaclePointType {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for FusionObstaclePointType {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::FusionObstaclePointType::default())
  }
}

impl rosidl_runtime_rs::Message for FusionObstaclePointType {
  type RmwMsg = super::msg::rmw::FusionObstaclePointType;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__FusionObstacleTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FusionObstacleTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for FusionObstacleTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::FusionObstacleTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for FusionObstacleTypeEnum {
  type RmwMsg = super::msg::rmw::FusionObstacleTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__GeneralDescriptor

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeneralDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::msg::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub global_descriptor_perception: super::msg::GlobalDescriptor,


    // This member is not documented.
    #[allow(missing_docs)]
    pub local_descriptor_perception: super::msg::LocalDescriptor,

}



impl Default for GeneralDescriptor {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GeneralDescriptor::default())
  }
}

impl rosidl_runtime_rs::Message for GeneralDescriptor {
  type RmwMsg = super::msg::rmw::GeneralDescriptor;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Owned(msg.meta)).into_owned(),
        global_descriptor_perception: super::msg::GlobalDescriptor::into_rmw_message(std::borrow::Cow::Owned(msg.global_descriptor_perception)).into_owned(),
        local_descriptor_perception: super::msg::LocalDescriptor::into_rmw_message(std::borrow::Cow::Owned(msg.local_descriptor_perception)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Borrowed(&msg.meta)).into_owned(),
        global_descriptor_perception: super::msg::GlobalDescriptor::into_rmw_message(std::borrow::Cow::Borrowed(&msg.global_descriptor_perception)).into_owned(),
        local_descriptor_perception: super::msg::LocalDescriptor::into_rmw_message(std::borrow::Cow::Borrowed(&msg.local_descriptor_perception)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      meta: super::msg::PerceptionMeta::from_rmw_message(msg.meta),
      global_descriptor_perception: super::msg::GlobalDescriptor::from_rmw_message(msg.global_descriptor_perception),
      local_descriptor_perception: super::msg::LocalDescriptor::from_rmw_message(msg.local_descriptor_perception),
    }
  }
}


// Corresponds to perception_msg__msg__GeneralObjectTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeneralObjectTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GeneralObjectTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GeneralObjectTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for GeneralObjectTypeEnum {
  type RmwMsg = super::msg::rmw::GeneralObjectTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__GlobalDescriptor

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::msg::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub global_descriptor: super::msg::GlobalDescriptorArray,

}



impl Default for GlobalDescriptor {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GlobalDescriptor::default())
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptor {
  type RmwMsg = super::msg::rmw::GlobalDescriptor;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Owned(msg.meta)).into_owned(),
        available: msg.available,
        global_descriptor: super::msg::GlobalDescriptorArray::into_rmw_message(std::borrow::Cow::Owned(msg.global_descriptor)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Borrowed(&msg.meta)).into_owned(),
      available: msg.available,
        global_descriptor: super::msg::GlobalDescriptorArray::into_rmw_message(std::borrow::Cow::Borrowed(&msg.global_descriptor)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      meta: super::msg::PerceptionMeta::from_rmw_message(msg.meta),
      available: msg.available,
      global_descriptor: super::msg::GlobalDescriptorArray::from_rmw_message(msg.global_descriptor),
    }
  }
}


// Corresponds to perception_msg__msg__GlobalDescriptorArray

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptorArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feature_descriptor: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub log_info_2d: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_info: std::string::String,

}



impl Default for GlobalDescriptorArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GlobalDescriptorArray::default())
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptorArray {
  type RmwMsg = super::msg::rmw::GlobalDescriptorArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag: msg.tag.as_str().into(),
        available: msg.available,
        feature_descriptor: msg.feature_descriptor.into(),
        log_info_2d: msg.log_info_2d.as_str().into(),
        reserved_info: msg.reserved_info.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag: msg.tag.as_str().into(),
      available: msg.available,
        feature_descriptor: msg.feature_descriptor.as_slice().into(),
        log_info_2d: msg.log_info_2d.as_str().into(),
        reserved_info: msg.reserved_info.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      tag: msg.tag.to_string(),
      available: msg.available,
      feature_descriptor: msg.feature_descriptor
          .into_iter()
          .collect(),
      log_info_2d: msg.log_info_2d.to_string(),
      reserved_info: msg.reserved_info.to_string(),
    }
  }
}


// Corresponds to perception_msg__msg__GlobalDescriptorPropertyEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GlobalDescriptorPropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GlobalDescriptorPropertyEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GlobalDescriptorPropertyEnum::default())
  }
}

impl rosidl_runtime_rs::Message for GlobalDescriptorPropertyEnum {
  type RmwMsg = super::msg::rmw::GlobalDescriptorPropertyEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__Grid1f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid1f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid1f: Vec<f32>,

}



impl Default for Grid1f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Grid1f::default())
  }
}

impl rosidl_runtime_rs::Message for Grid1f {
  type RmwMsg = super::msg::rmw::Grid1f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid1f: msg.grid1f.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid1f: msg.grid1f.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      grid1f: msg.grid1f
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__Grid2f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid2f: Vec<super::msg::Grid1f>,

}



impl Default for Grid2f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Grid2f::default())
  }
}

impl rosidl_runtime_rs::Message for Grid2f {
  type RmwMsg = super::msg::rmw::Grid2f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid2f: msg.grid2f
          .into_iter()
          .map(|elem| super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid2f: msg.grid2f
          .iter()
          .map(|elem| super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      grid2f: msg.grid2f
          .into_iter()
          .map(super::msg::Grid1f::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__Grid3f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grid3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub grid3f: Vec<super::msg::Grid2f>,

}



impl Default for Grid3f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Grid3f::default())
  }
}

impl rosidl_runtime_rs::Message for Grid3f {
  type RmwMsg = super::msg::rmw::Grid3f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid3f: msg.grid3f
          .into_iter()
          .map(|elem| super::msg::Grid2f::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        grid3f: msg.grid3f
          .iter()
          .map(|elem| super::msg::Grid2f::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      grid3f: msg.grid3f
          .into_iter()
          .map(super::msg::Grid2f::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__GroundPerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GroundPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_camera_exposure: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_preprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_before_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_postprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_model_result_publish: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_types: super::msg::VoxelGroundTypes,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_heights: super::msg::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ground_type_scores: super::msg::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for GroundPerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GroundPerception::default())
  }
}

impl rosidl_runtime_rs::Message for GroundPerception {
  type RmwMsg = super::msg::rmw::GroundPerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        available: msg.available,
        timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
        timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
        timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
        timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
        timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
        timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
        x_min: msg.x_min,
        x_max: msg.x_max,
        x_num_bin: msg.x_num_bin,
        y_min: msg.y_min,
        y_max: msg.y_max,
        y_num_bin: msg.y_num_bin,
        ground_types: super::msg::VoxelGroundTypes::into_rmw_message(std::borrow::Cow::Owned(msg.ground_types)).into_owned(),
        ground_heights: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Owned(msg.ground_heights)).into_owned(),
        ground_type_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Owned(msg.ground_type_scores)).into_owned(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      available: msg.available,
      timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
      timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
      timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
      timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
      timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
      timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
      x_min: msg.x_min,
      x_max: msg.x_max,
      x_num_bin: msg.x_num_bin,
      y_min: msg.y_min,
      y_max: msg.y_max,
      y_num_bin: msg.y_num_bin,
        ground_types: super::msg::VoxelGroundTypes::into_rmw_message(std::borrow::Cow::Borrowed(&msg.ground_types)).into_owned(),
        ground_heights: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.ground_heights)).into_owned(),
        ground_type_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.ground_type_scores)).into_owned(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      available: msg.available,
      timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
      timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
      timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
      timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
      timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
      timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
      x_min: msg.x_min,
      x_max: msg.x_max,
      x_num_bin: msg.x_num_bin,
      y_min: msg.y_min,
      y_max: msg.y_max,
      y_num_bin: msg.y_num_bin,
      ground_types: super::msg::VoxelGroundTypes::from_rmw_message(msg.ground_types),
      ground_heights: super::msg::Grid1f::from_rmw_message(msg.ground_heights),
      ground_type_scores: super::msg::Grid1f::from_rmw_message(msg.ground_type_scores),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__GroundTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GroundTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for GroundTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GroundTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for GroundTypeEnum {
  type RmwMsg = super::msg::rmw::GroundTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__Lane

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Lane {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub index: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_x: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_y: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d_v: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub coefficient_bv: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub coefficient_bv_sigma: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_failed_3d: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_type: super::msg::LaneTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_color: super::msg::LaneColorEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_width: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_centerline: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_x: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_y: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d_z: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_horizontal_line: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_horizontal_type: super::msg::LaneHorizontalTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stopline_depth: f32,

}



impl Default for Lane {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Lane::default())
  }
}

impl rosidl_runtime_rs::Message for Lane {
  type RmwMsg = super::msg::rmw::Lane;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
        score: msg.score,
        index: msg.index,
        points_2d_x: msg.points_2d_x.into(),
        points_2d_y: msg.points_2d_y.into(),
        points_2d_v: msg.points_2d_v.into(),
        track_id: msg.track_id,
        coefficient_bv: msg.coefficient_bv.into(),
        coefficient_bv_sigma: msg.coefficient_bv_sigma.into(),
        is_failed_3d: msg.is_failed_3d,
        lane_type: super::msg::LaneTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.lane_type)).into_owned(),
        lane_color: super::msg::LaneColorEnum::into_rmw_message(std::borrow::Cow::Owned(msg.lane_color)).into_owned(),
        lane_width: msg.lane_width,
        is_centerline: msg.is_centerline,
        points_3d_x: msg.points_3d_x.into(),
        points_3d_y: msg.points_3d_y.into(),
        points_3d_z: msg.points_3d_z.into(),
        is_horizontal_line: msg.is_horizontal_line,
        lane_horizontal_type: super::msg::LaneHorizontalTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.lane_horizontal_type)).into_owned(),
        stopline_depth: msg.stopline_depth,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
      score: msg.score,
      index: msg.index,
        points_2d_x: msg.points_2d_x.as_slice().into(),
        points_2d_y: msg.points_2d_y.as_slice().into(),
        points_2d_v: msg.points_2d_v.as_slice().into(),
      track_id: msg.track_id,
        coefficient_bv: msg.coefficient_bv.as_slice().into(),
        coefficient_bv_sigma: msg.coefficient_bv_sigma.as_slice().into(),
      is_failed_3d: msg.is_failed_3d,
        lane_type: super::msg::LaneTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.lane_type)).into_owned(),
        lane_color: super::msg::LaneColorEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.lane_color)).into_owned(),
      lane_width: msg.lane_width,
      is_centerline: msg.is_centerline,
        points_3d_x: msg.points_3d_x.as_slice().into(),
        points_3d_y: msg.points_3d_y.as_slice().into(),
        points_3d_z: msg.points_3d_z.as_slice().into(),
      is_horizontal_line: msg.is_horizontal_line,
        lane_horizontal_type: super::msg::LaneHorizontalTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.lane_horizontal_type)).into_owned(),
      stopline_depth: msg.stopline_depth,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
      score: msg.score,
      index: msg.index,
      points_2d_x: msg.points_2d_x
          .into_iter()
          .collect(),
      points_2d_y: msg.points_2d_y
          .into_iter()
          .collect(),
      points_2d_v: msg.points_2d_v
          .into_iter()
          .collect(),
      track_id: msg.track_id,
      coefficient_bv: msg.coefficient_bv
          .into_iter()
          .collect(),
      coefficient_bv_sigma: msg.coefficient_bv_sigma
          .into_iter()
          .collect(),
      is_failed_3d: msg.is_failed_3d,
      lane_type: super::msg::LaneTypeEnum::from_rmw_message(msg.lane_type),
      lane_color: super::msg::LaneColorEnum::from_rmw_message(msg.lane_color),
      lane_width: msg.lane_width,
      is_centerline: msg.is_centerline,
      points_3d_x: msg.points_3d_x
          .into_iter()
          .collect(),
      points_3d_y: msg.points_3d_y
          .into_iter()
          .collect(),
      points_3d_z: msg.points_3d_z
          .into_iter()
          .collect(),
      is_horizontal_line: msg.is_horizontal_line,
      lane_horizontal_type: super::msg::LaneHorizontalTypeEnum::from_rmw_message(msg.lane_horizontal_type),
      stopline_depth: msg.stopline_depth,
    }
  }
}


// Corresponds to perception_msg__msg__LaneColorEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneColorEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneColorEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneColorEnum::default())
  }
}

impl rosidl_runtime_rs::Message for LaneColorEnum {
  type RmwMsg = super::msg::rmw::LaneColorEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__LaneHorizontalTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneHorizontalTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneHorizontalTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneHorizontalTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for LaneHorizontalTypeEnum {
  type RmwMsg = super::msg::rmw::LaneHorizontalTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__LanePerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LanePerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lanes: Vec<super::msg::Lane>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for LanePerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LanePerception::default())
  }
}

impl rosidl_runtime_rs::Message for LanePerception {
  type RmwMsg = super::msg::rmw::LanePerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        available: msg.available,
        lanes: msg.lanes
          .into_iter()
          .map(|elem| super::msg::Lane::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      available: msg.available,
        lanes: msg.lanes
          .iter()
          .map(|elem| super::msg::Lane::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      available: msg.available,
      lanes: msg.lanes
          .into_iter()
          .map(super::msg::Lane::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__LaneSegment

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegment {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: Vec<super::msg::Point2f>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_3d: Vec<super::msg::Point3f>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_track_id: Vec<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_score: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_type: Vec<super::msg::LaneSegmentPointEnum>,

}



impl Default for LaneSegment {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneSegment::default())
  }
}

impl rosidl_runtime_rs::Message for LaneSegment {
  type RmwMsg = super::msg::rmw::LaneSegment;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
        points_2d: msg.points_2d
          .into_iter()
          .map(|elem| super::msg::Point2f::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        points_3d: msg.points_3d
          .into_iter()
          .map(|elem| super::msg::Point3f::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        points_track_id: msg.points_track_id.into(),
        points_score: msg.points_score.into(),
        points_type: msg.points_type
          .into_iter()
          .map(|elem| super::msg::LaneSegmentPointEnum::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
        points_2d: msg.points_2d
          .iter()
          .map(|elem| super::msg::Point2f::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        points_3d: msg.points_3d
          .iter()
          .map(|elem| super::msg::Point3f::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        points_track_id: msg.points_track_id.as_slice().into(),
        points_score: msg.points_score.as_slice().into(),
        points_type: msg.points_type
          .iter()
          .map(|elem| super::msg::LaneSegmentPointEnum::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
      points_2d: msg.points_2d
          .into_iter()
          .map(super::msg::Point2f::from_rmw_message)
          .collect(),
      points_3d: msg.points_3d
          .into_iter()
          .map(super::msg::Point3f::from_rmw_message)
          .collect(),
      points_track_id: msg.points_track_id
          .into_iter()
          .collect(),
      points_score: msg.points_score
          .into_iter()
          .collect(),
      points_type: msg.points_type
          .into_iter()
          .map(super::msg::LaneSegmentPointEnum::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__LaneSegmentPerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegmentPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lane_segments: Vec<super::msg::LaneSegment>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for LaneSegmentPerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneSegmentPerception::default())
  }
}

impl rosidl_runtime_rs::Message for LaneSegmentPerception {
  type RmwMsg = super::msg::rmw::LaneSegmentPerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        available: msg.available,
        lane_segments: msg.lane_segments
          .into_iter()
          .map(|elem| super::msg::LaneSegment::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      available: msg.available,
        lane_segments: msg.lane_segments
          .iter()
          .map(|elem| super::msg::LaneSegment::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      available: msg.available,
      lane_segments: msg.lane_segments
          .into_iter()
          .map(super::msg::LaneSegment::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__LaneSegmentPointEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneSegmentPointEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneSegmentPointEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneSegmentPointEnum::default())
  }
}

impl rosidl_runtime_rs::Message for LaneSegmentPointEnum {
  type RmwMsg = super::msg::rmw::LaneSegmentPointEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__LaneTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LaneTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LaneTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LaneTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for LaneTypeEnum {
  type RmwMsg = super::msg::rmw::LaneTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__LocalDescriptor

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptor {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::msg::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub local_descriptor_arrays: Vec<super::msg::LocalDescriptorArray>,

}



impl Default for LocalDescriptor {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LocalDescriptor::default())
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptor {
  type RmwMsg = super::msg::rmw::LocalDescriptor;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Owned(msg.meta)).into_owned(),
        available: msg.available,
        local_descriptor_arrays: msg.local_descriptor_arrays
          .into_iter()
          .map(|elem| super::msg::LocalDescriptorArray::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Borrowed(&msg.meta)).into_owned(),
      available: msg.available,
        local_descriptor_arrays: msg.local_descriptor_arrays
          .iter()
          .map(|elem| super::msg::LocalDescriptorArray::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      meta: super::msg::PerceptionMeta::from_rmw_message(msg.meta),
      available: msg.available,
      local_descriptor_arrays: msg.local_descriptor_arrays
          .into_iter()
          .map(super::msg::LocalDescriptorArray::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__LocalDescriptorArray

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptorArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_point: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_ids: Vec<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub point_xs: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub point_ys: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub descriptor_size: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub descriptors: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub log_info_2d: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_info: std::string::String,

}



impl Default for LocalDescriptorArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LocalDescriptorArray::default())
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptorArray {
  type RmwMsg = super::msg::rmw::LocalDescriptorArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag: msg.tag.as_str().into(),
        available: msg.available,
        num_point: msg.num_point,
        track_ids: msg.track_ids.into(),
        point_xs: msg.point_xs.into(),
        point_ys: msg.point_ys.into(),
        descriptor_size: msg.descriptor_size,
        descriptors: msg.descriptors.into(),
        log_info_2d: msg.log_info_2d.as_str().into(),
        reserved_info: msg.reserved_info.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag: msg.tag.as_str().into(),
      available: msg.available,
      num_point: msg.num_point,
        track_ids: msg.track_ids.as_slice().into(),
        point_xs: msg.point_xs.as_slice().into(),
        point_ys: msg.point_ys.as_slice().into(),
      descriptor_size: msg.descriptor_size,
        descriptors: msg.descriptors.as_slice().into(),
        log_info_2d: msg.log_info_2d.as_str().into(),
        reserved_info: msg.reserved_info.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      tag: msg.tag.to_string(),
      available: msg.available,
      num_point: msg.num_point,
      track_ids: msg.track_ids
          .into_iter()
          .collect(),
      point_xs: msg.point_xs
          .into_iter()
          .collect(),
      point_ys: msg.point_ys
          .into_iter()
          .collect(),
      descriptor_size: msg.descriptor_size,
      descriptors: msg.descriptors
          .into_iter()
          .collect(),
      log_info_2d: msg.log_info_2d.to_string(),
      reserved_info: msg.reserved_info.to_string(),
    }
  }
}


// Corresponds to perception_msg__msg__LocalDescriptorArrayPropertyEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocalDescriptorArrayPropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LocalDescriptorArrayPropertyEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LocalDescriptorArrayPropertyEnum::default())
  }
}

impl rosidl_runtime_rs::Message for LocalDescriptorArrayPropertyEnum {
  type RmwMsg = super::msg::rmw::LocalDescriptorArrayPropertyEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__LocationInfo

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LocationInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_valid: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qy: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub qz: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub tx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ty: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub tz: f32,

}



impl Default for LocationInfo {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LocationInfo::default())
  }
}

impl rosidl_runtime_rs::Message for LocationInfo {
  type RmwMsg = super::msg::rmw::LocationInfo;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        is_valid: msg.is_valid,
        qw: msg.qw,
        qx: msg.qx,
        qy: msg.qy,
        qz: msg.qz,
        tx: msg.tx,
        ty: msg.ty,
        tz: msg.tz,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      is_valid: msg.is_valid,
      qw: msg.qw,
      qx: msg.qx,
      qy: msg.qy,
      qz: msg.qz,
      tx: msg.tx,
      ty: msg.ty,
      tz: msg.tz,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      is_valid: msg.is_valid,
      qw: msg.qw,
      qx: msg.qx,
      qy: msg.qy,
      qz: msg.qz,
      tx: msg.tx,
      ty: msg.ty,
      tz: msg.tz,
    }
  }
}


// Corresponds to perception_msg__msg__Object

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Object {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::msg::ObjectTypeInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility_2d: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bounding_box_2d: super::msg::Rect4f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_info: super::msg::ObjectTrackInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reid_feature: super::msg::ObjectReIdFeature,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape_3d: super::msg::Shape3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub heading_theta_bv: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity_bv: super::msg::Vector3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub location_bv: super::msg::Point3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ttc: f32,

}



impl Default for Object {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Object::default())
  }
}

impl rosidl_runtime_rs::Message for Object {
  type RmwMsg = super::msg::rmw::Object;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
        type_info: super::msg::ObjectTypeInfo::into_rmw_message(std::borrow::Cow::Owned(msg.type_info)).into_owned(),
        score: msg.score,
        visibility_2d: msg.visibility_2d,
        bounding_box_2d: super::msg::Rect4f::into_rmw_message(std::borrow::Cow::Owned(msg.bounding_box_2d)).into_owned(),
        track_info: super::msg::ObjectTrackInfo::into_rmw_message(std::borrow::Cow::Owned(msg.track_info)).into_owned(),
        reid_feature: super::msg::ObjectReIdFeature::into_rmw_message(std::borrow::Cow::Owned(msg.reid_feature)).into_owned(),
        shape_3d: super::msg::Shape3f::into_rmw_message(std::borrow::Cow::Owned(msg.shape_3d)).into_owned(),
        heading_theta_bv: msg.heading_theta_bv,
        velocity_bv: super::msg::Vector3f::into_rmw_message(std::borrow::Cow::Owned(msg.velocity_bv)).into_owned(),
        location_bv: super::msg::Point3f::into_rmw_message(std::borrow::Cow::Owned(msg.location_bv)).into_owned(),
        ttc: msg.ttc,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
        type_info: super::msg::ObjectTypeInfo::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_info)).into_owned(),
      score: msg.score,
      visibility_2d: msg.visibility_2d,
        bounding_box_2d: super::msg::Rect4f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.bounding_box_2d)).into_owned(),
        track_info: super::msg::ObjectTrackInfo::into_rmw_message(std::borrow::Cow::Borrowed(&msg.track_info)).into_owned(),
        reid_feature: super::msg::ObjectReIdFeature::into_rmw_message(std::borrow::Cow::Borrowed(&msg.reid_feature)).into_owned(),
        shape_3d: super::msg::Shape3f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.shape_3d)).into_owned(),
      heading_theta_bv: msg.heading_theta_bv,
        velocity_bv: super::msg::Vector3f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.velocity_bv)).into_owned(),
        location_bv: super::msg::Point3f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.location_bv)).into_owned(),
      ttc: msg.ttc,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
      type_info: super::msg::ObjectTypeInfo::from_rmw_message(msg.type_info),
      score: msg.score,
      visibility_2d: msg.visibility_2d,
      bounding_box_2d: super::msg::Rect4f::from_rmw_message(msg.bounding_box_2d),
      track_info: super::msg::ObjectTrackInfo::from_rmw_message(msg.track_info),
      reid_feature: super::msg::ObjectReIdFeature::from_rmw_message(msg.reid_feature),
      shape_3d: super::msg::Shape3f::from_rmw_message(msg.shape_3d),
      heading_theta_bv: msg.heading_theta_bv,
      velocity_bv: super::msg::Vector3f::from_rmw_message(msg.velocity_bv),
      location_bv: super::msg::Point3f::from_rmw_message(msg.location_bv),
      ttc: msg.ttc,
    }
  }
}


// Corresponds to perception_msg__msg__ObjectPerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::msg::PerceptionMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub objects: Vec<super::msg::Object>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for ObjectPerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectPerception::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectPerception {
  type RmwMsg = super::msg::rmw::ObjectPerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Owned(msg.meta)).into_owned(),
        available: msg.available,
        objects: msg.objects
          .into_iter()
          .map(|elem| super::msg::Object::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        meta: super::msg::PerceptionMeta::into_rmw_message(std::borrow::Cow::Borrowed(&msg.meta)).into_owned(),
      available: msg.available,
        objects: msg.objects
          .iter()
          .map(|elem| super::msg::Object::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      meta: super::msg::PerceptionMeta::from_rmw_message(msg.meta),
      available: msg.available,
      objects: msg.objects
          .into_iter()
          .map(super::msg::Object::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__ObjectReIdFeature

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectReIdFeature {

    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<f32>,

}



impl Default for ObjectReIdFeature {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectReIdFeature::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectReIdFeature {
  type RmwMsg = super::msg::rmw::ObjectReIdFeature;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        data: msg.data.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      data: msg.data
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__ObjectTrackInfo

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTrackInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_times: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub age_in_seconds: f32,

}



impl Default for ObjectTrackInfo {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectTrackInfo::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectTrackInfo {
  type RmwMsg = super::msg::rmw::ObjectTrackInfo;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        track_id: msg.track_id,
        track_times: msg.track_times,
        age_in_seconds: msg.age_in_seconds,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      track_id: msg.track_id,
      track_times: msg.track_times,
      age_in_seconds: msg.age_in_seconds,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      track_id: msg.track_id,
      track_times: msg.track_times,
      age_in_seconds: msg.age_in_seconds,
    }
  }
}


// Corresponds to perception_msg__msg__ObjectTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for ObjectTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectTypeEnum {
  type RmwMsg = super::msg::rmw::ObjectTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__ObjectTypeInfo

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypeInfo {

    // This member is not documented.
    #[allow(missing_docs)]
    pub type_properties: Vec<super::msg::ObjectTypePropertyEnum>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::msg::ObjectTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub general_object_type: super::msg::GeneralObjectTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vsu_type: super::msg::VsuTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vsu_sub_type: super::msg::VsuSubTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub barrier_type: super::msg::BarrierTypeEnum,

}



impl Default for ObjectTypeInfo {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectTypeInfo::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectTypeInfo {
  type RmwMsg = super::msg::rmw::ObjectTypeInfo;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        type_properties: msg.type_properties
          .into_iter()
          .map(|elem| super::msg::ObjectTypePropertyEnum::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        type_: super::msg::ObjectTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.type_)).into_owned(),
        general_object_type: super::msg::GeneralObjectTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.general_object_type)).into_owned(),
        vsu_type: super::msg::VsuTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.vsu_type)).into_owned(),
        vsu_sub_type: super::msg::VsuSubTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.vsu_sub_type)).into_owned(),
        barrier_type: super::msg::BarrierTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.barrier_type)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        type_properties: msg.type_properties
          .iter()
          .map(|elem| super::msg::ObjectTypePropertyEnum::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        type_: super::msg::ObjectTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_)).into_owned(),
        general_object_type: super::msg::GeneralObjectTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.general_object_type)).into_owned(),
        vsu_type: super::msg::VsuTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.vsu_type)).into_owned(),
        vsu_sub_type: super::msg::VsuSubTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.vsu_sub_type)).into_owned(),
        barrier_type: super::msg::BarrierTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.barrier_type)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      type_properties: msg.type_properties
          .into_iter()
          .map(super::msg::ObjectTypePropertyEnum::from_rmw_message)
          .collect(),
      type_: super::msg::ObjectTypeEnum::from_rmw_message(msg.type_),
      general_object_type: super::msg::GeneralObjectTypeEnum::from_rmw_message(msg.general_object_type),
      vsu_type: super::msg::VsuTypeEnum::from_rmw_message(msg.vsu_type),
      vsu_sub_type: super::msg::VsuSubTypeEnum::from_rmw_message(msg.vsu_sub_type),
      barrier_type: super::msg::BarrierTypeEnum::from_rmw_message(msg.barrier_type),
    }
  }
}


// Corresponds to perception_msg__msg__ObjectTypePropertyEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ObjectTypePropertyEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for ObjectTypePropertyEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ObjectTypePropertyEnum::default())
  }
}

impl rosidl_runtime_rs::Message for ObjectTypePropertyEnum {
  type RmwMsg = super::msg::rmw::ObjectTypePropertyEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__OccupancyPerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct OccupancyPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_camera_exposure: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_preprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_before_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_process: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_after_model_postprocess: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp_us_model_result_publish: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_min: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_max: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z_num_bin: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_states: super::msg::VoxelStates,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_state_scores: super::msg::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_types: super::msg::VoxelTypes,


    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_type_scores: super::msg::Grid1f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for OccupancyPerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::OccupancyPerception::default())
  }
}

impl rosidl_runtime_rs::Message for OccupancyPerception {
  type RmwMsg = super::msg::rmw::OccupancyPerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        available: msg.available,
        timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
        timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
        timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
        timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
        timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
        timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
        x_min: msg.x_min,
        x_max: msg.x_max,
        x_num_bin: msg.x_num_bin,
        y_min: msg.y_min,
        y_max: msg.y_max,
        y_num_bin: msg.y_num_bin,
        z_min: msg.z_min,
        z_max: msg.z_max,
        z_num_bin: msg.z_num_bin,
        voxel_states: super::msg::VoxelStates::into_rmw_message(std::borrow::Cow::Owned(msg.voxel_states)).into_owned(),
        voxel_state_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Owned(msg.voxel_state_scores)).into_owned(),
        voxel_types: super::msg::VoxelTypes::into_rmw_message(std::borrow::Cow::Owned(msg.voxel_types)).into_owned(),
        voxel_type_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Owned(msg.voxel_type_scores)).into_owned(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      available: msg.available,
      timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
      timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
      timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
      timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
      timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
      timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
      x_min: msg.x_min,
      x_max: msg.x_max,
      x_num_bin: msg.x_num_bin,
      y_min: msg.y_min,
      y_max: msg.y_max,
      y_num_bin: msg.y_num_bin,
      z_min: msg.z_min,
      z_max: msg.z_max,
      z_num_bin: msg.z_num_bin,
        voxel_states: super::msg::VoxelStates::into_rmw_message(std::borrow::Cow::Borrowed(&msg.voxel_states)).into_owned(),
        voxel_state_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.voxel_state_scores)).into_owned(),
        voxel_types: super::msg::VoxelTypes::into_rmw_message(std::borrow::Cow::Borrowed(&msg.voxel_types)).into_owned(),
        voxel_type_scores: super::msg::Grid1f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.voxel_type_scores)).into_owned(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      available: msg.available,
      timestamp_us_camera_exposure: msg.timestamp_us_camera_exposure,
      timestamp_us_after_model_preprocess: msg.timestamp_us_after_model_preprocess,
      timestamp_us_before_model_process: msg.timestamp_us_before_model_process,
      timestamp_us_after_model_process: msg.timestamp_us_after_model_process,
      timestamp_us_after_model_postprocess: msg.timestamp_us_after_model_postprocess,
      timestamp_us_model_result_publish: msg.timestamp_us_model_result_publish,
      x_min: msg.x_min,
      x_max: msg.x_max,
      x_num_bin: msg.x_num_bin,
      y_min: msg.y_min,
      y_max: msg.y_max,
      y_num_bin: msg.y_num_bin,
      z_min: msg.z_min,
      z_max: msg.z_max,
      z_num_bin: msg.z_num_bin,
      voxel_states: super::msg::VoxelStates::from_rmw_message(msg.voxel_states),
      voxel_state_scores: super::msg::Grid1f::from_rmw_message(msg.voxel_state_scores),
      voxel_types: super::msg::VoxelTypes::from_rmw_message(msg.voxel_types),
      voxel_type_scores: super::msg::Grid1f::from_rmw_message(msg.voxel_type_scores),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__PerceptionFusionObjectData

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionObjectData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::msg::ObjectTypeInfo,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_static: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub static_confidence: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape: super::msg::Shape3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::msg::Point3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub acceleration: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub heading_yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub angular_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_position: super::msg::Point3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_velocity: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_acceleration: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_heading_yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relative_angular_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity_relative_to_ground: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub acceleration_relative_to_ground: super::msg::Vector3d,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub crash_risk_ttc: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub polygon_bottom: super::msg::Polygon3f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub polygon_top: super::msg::Polygon3f,

}



impl Default for PerceptionFusionObjectData {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PerceptionFusionObjectData::default())
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionObjectData {
  type RmwMsg = super::msg::rmw::PerceptionFusionObjectData;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        track_id: msg.track_id,
        type_info: super::msg::ObjectTypeInfo::into_rmw_message(std::borrow::Cow::Owned(msg.type_info)).into_owned(),
        is_static: msg.is_static,
        static_confidence: msg.static_confidence,
        shape: super::msg::Shape3d::into_rmw_message(std::borrow::Cow::Owned(msg.shape)).into_owned(),
        position: super::msg::Point3d::into_rmw_message(std::borrow::Cow::Owned(msg.position)).into_owned(),
        velocity: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.velocity)).into_owned(),
        acceleration: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.acceleration)).into_owned(),
        heading_yaw: msg.heading_yaw,
        angular_velocity: msg.angular_velocity,
        relative_position: super::msg::Point3d::into_rmw_message(std::borrow::Cow::Owned(msg.relative_position)).into_owned(),
        relative_velocity: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.relative_velocity)).into_owned(),
        relative_acceleration: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.relative_acceleration)).into_owned(),
        relative_heading_yaw: msg.relative_heading_yaw,
        relative_angular_velocity: msg.relative_angular_velocity,
        velocity_relative_to_ground: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.velocity_relative_to_ground)).into_owned(),
        acceleration_relative_to_ground: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Owned(msg.acceleration_relative_to_ground)).into_owned(),
        score: msg.score,
        crash_risk_ttc: msg.crash_risk_ttc,
        polygon_bottom: super::msg::Polygon3f::into_rmw_message(std::borrow::Cow::Owned(msg.polygon_bottom)).into_owned(),
        polygon_top: super::msg::Polygon3f::into_rmw_message(std::borrow::Cow::Owned(msg.polygon_top)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      track_id: msg.track_id,
        type_info: super::msg::ObjectTypeInfo::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_info)).into_owned(),
      is_static: msg.is_static,
      static_confidence: msg.static_confidence,
        shape: super::msg::Shape3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.shape)).into_owned(),
        position: super::msg::Point3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.position)).into_owned(),
        velocity: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.velocity)).into_owned(),
        acceleration: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.acceleration)).into_owned(),
      heading_yaw: msg.heading_yaw,
      angular_velocity: msg.angular_velocity,
        relative_position: super::msg::Point3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.relative_position)).into_owned(),
        relative_velocity: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.relative_velocity)).into_owned(),
        relative_acceleration: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.relative_acceleration)).into_owned(),
      relative_heading_yaw: msg.relative_heading_yaw,
      relative_angular_velocity: msg.relative_angular_velocity,
        velocity_relative_to_ground: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.velocity_relative_to_ground)).into_owned(),
        acceleration_relative_to_ground: super::msg::Vector3d::into_rmw_message(std::borrow::Cow::Borrowed(&msg.acceleration_relative_to_ground)).into_owned(),
      score: msg.score,
      crash_risk_ttc: msg.crash_risk_ttc,
        polygon_bottom: super::msg::Polygon3f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.polygon_bottom)).into_owned(),
        polygon_top: super::msg::Polygon3f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.polygon_top)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      track_id: msg.track_id,
      type_info: super::msg::ObjectTypeInfo::from_rmw_message(msg.type_info),
      is_static: msg.is_static,
      static_confidence: msg.static_confidence,
      shape: super::msg::Shape3d::from_rmw_message(msg.shape),
      position: super::msg::Point3d::from_rmw_message(msg.position),
      velocity: super::msg::Vector3d::from_rmw_message(msg.velocity),
      acceleration: super::msg::Vector3d::from_rmw_message(msg.acceleration),
      heading_yaw: msg.heading_yaw,
      angular_velocity: msg.angular_velocity,
      relative_position: super::msg::Point3d::from_rmw_message(msg.relative_position),
      relative_velocity: super::msg::Vector3d::from_rmw_message(msg.relative_velocity),
      relative_acceleration: super::msg::Vector3d::from_rmw_message(msg.relative_acceleration),
      relative_heading_yaw: msg.relative_heading_yaw,
      relative_angular_velocity: msg.relative_angular_velocity,
      velocity_relative_to_ground: super::msg::Vector3d::from_rmw_message(msg.velocity_relative_to_ground),
      acceleration_relative_to_ground: super::msg::Vector3d::from_rmw_message(msg.acceleration_relative_to_ground),
      score: msg.score,
      crash_risk_ttc: msg.crash_risk_ttc,
      polygon_bottom: super::msg::Polygon3f::from_rmw_message(msg.polygon_bottom),
      polygon_top: super::msg::Polygon3f::from_rmw_message(msg.polygon_top),
    }
  }
}


// Corresponds to perception_msg__msg__PerceptionFusionObjectResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionObjectResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub meta: super::msg::PerceptionFusionResultMeta,


    // This member is not documented.
    #[allow(missing_docs)]
    pub perception_fusion_objects_data: Vec<super::msg::PerceptionFusionObjectData>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for PerceptionFusionObjectResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PerceptionFusionObjectResult::default())
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionObjectResult {
  type RmwMsg = super::msg::rmw::PerceptionFusionObjectResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        meta: super::msg::PerceptionFusionResultMeta::into_rmw_message(std::borrow::Cow::Owned(msg.meta)).into_owned(),
        perception_fusion_objects_data: msg.perception_fusion_objects_data
          .into_iter()
          .map(|elem| super::msg::PerceptionFusionObjectData::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        meta: super::msg::PerceptionFusionResultMeta::into_rmw_message(std::borrow::Cow::Borrowed(&msg.meta)).into_owned(),
        perception_fusion_objects_data: msg.perception_fusion_objects_data
          .iter()
          .map(|elem| super::msg::PerceptionFusionObjectData::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      meta: super::msg::PerceptionFusionResultMeta::from_rmw_message(msg.meta),
      perception_fusion_objects_data: msg.perception_fusion_objects_data
          .into_iter()
          .map(super::msg::PerceptionFusionObjectData::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__PerceptionFusionResultMeta

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionFusionResultMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_start_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_finish_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version_tag: std::string::String,

}



impl Default for PerceptionFusionResultMeta {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PerceptionFusionResultMeta::default())
  }
}

impl rosidl_runtime_rs::Message for PerceptionFusionResultMeta {
  type RmwMsg = super::msg::rmw::PerceptionFusionResultMeta;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        sensor_timestamp_us: msg.sensor_timestamp_us,
        pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
        pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
        version_tag: msg.version_tag.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      sensor_timestamp_us: msg.sensor_timestamp_us,
      pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
      pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
        version_tag: msg.version_tag.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      sensor_timestamp_us: msg.sensor_timestamp_us,
      pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
      pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
      version_tag: msg.version_tag.to_string(),
    }
  }
}


// Corresponds to perception_msg__msg__PerceptionMeta

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PerceptionMeta {

    // This member is not documented.
    #[allow(missing_docs)]
    pub algorithm_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub instance_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_start_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pipeline_finish_timestamp_us: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub relevant_frames: Vec<super::msg::FrameMeta>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version_tag: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ts_log: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_tag: std::string::String,

}



impl Default for PerceptionMeta {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PerceptionMeta::default())
  }
}

impl rosidl_runtime_rs::Message for PerceptionMeta {
  type RmwMsg = super::msg::rmw::PerceptionMeta;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        algorithm_name: msg.algorithm_name.as_str().into(),
        instance_name: msg.instance_name.as_str().into(),
        sensor_timestamp_us: msg.sensor_timestamp_us,
        pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
        pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
        relevant_frames: msg.relevant_frames
          .into_iter()
          .map(|elem| super::msg::FrameMeta::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        version_tag: msg.version_tag.as_str().into(),
        ts_log: msg.ts_log.as_str().into(),
        sequence: msg.sequence,
        task_tag: msg.task_tag.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        algorithm_name: msg.algorithm_name.as_str().into(),
        instance_name: msg.instance_name.as_str().into(),
      sensor_timestamp_us: msg.sensor_timestamp_us,
      pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
      pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
        relevant_frames: msg.relevant_frames
          .iter()
          .map(|elem| super::msg::FrameMeta::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        version_tag: msg.version_tag.as_str().into(),
        ts_log: msg.ts_log.as_str().into(),
      sequence: msg.sequence,
        task_tag: msg.task_tag.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      algorithm_name: msg.algorithm_name.to_string(),
      instance_name: msg.instance_name.to_string(),
      sensor_timestamp_us: msg.sensor_timestamp_us,
      pipeline_start_timestamp_us: msg.pipeline_start_timestamp_us,
      pipeline_finish_timestamp_us: msg.pipeline_finish_timestamp_us,
      relevant_frames: msg.relevant_frames
          .into_iter()
          .map(super::msg::FrameMeta::from_rmw_message)
          .collect(),
      version_tag: msg.version_tag.to_string(),
      ts_log: msg.ts_log.to_string(),
      sequence: msg.sequence,
      task_tag: msg.task_tag.to_string(),
    }
  }
}


// Corresponds to perception_msg__msg__Point2d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,

}



impl Default for Point2d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Point2d::default())
  }
}

impl rosidl_runtime_rs::Message for Point2d {
  type RmwMsg = super::msg::rmw::Point2d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
    }
  }
}


// Corresponds to perception_msg__msg__Point2f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,

}



impl Default for Point2f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Point2f::default())
  }
}

impl rosidl_runtime_rs::Message for Point2f {
  type RmwMsg = super::msg::rmw::Point2f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
    }
  }
}


// Corresponds to perception_msg__msg__Point3d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f64,

}



impl Default for Point3d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Point3d::default())
  }
}

impl rosidl_runtime_rs::Message for Point3d {
  type RmwMsg = super::msg::rmw::Point3d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
        z: msg.z,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      z: msg.z,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
      z: msg.z,
    }
  }
}


// Corresponds to perception_msg__msg__Point3f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Point3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,

}



impl Default for Point3f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Point3f::default())
  }
}

impl rosidl_runtime_rs::Message for Point3f {
  type RmwMsg = super::msg::rmw::Point3f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
        z: msg.z,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      z: msg.z,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
      z: msg.z,
    }
  }
}


// Corresponds to perception_msg__msg__PoleLine

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLine {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: Vec<super::msg::PoleLinePoint>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::msg::PoleLineTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,

}



impl Default for PoleLine {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PoleLine::default())
  }
}

impl rosidl_runtime_rs::Message for PoleLine {
  type RmwMsg = super::msg::rmw::PoleLine;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
        score: msg.score,
        points_2d: msg.points_2d
          .into_iter()
          .map(|elem| super::msg::PoleLinePoint::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        type_: super::msg::PoleLineTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.type_)).into_owned(),
        track_id: msg.track_id,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
      score: msg.score,
        points_2d: msg.points_2d
          .iter()
          .map(|elem| super::msg::PoleLinePoint::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        type_: super::msg::PoleLineTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_)).into_owned(),
      track_id: msg.track_id,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
      score: msg.score,
      points_2d: msg.points_2d
          .into_iter()
          .map(super::msg::PoleLinePoint::from_rmw_message)
          .collect(),
      type_: super::msg::PoleLineTypeEnum::from_rmw_message(msg.type_),
      track_id: msg.track_id,
    }
  }
}


// Corresponds to perception_msg__msg__PoleLinePerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLinePerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pole_lines: Vec<super::msg::PoleLine>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for PoleLinePerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PoleLinePerception::default())
  }
}

impl rosidl_runtime_rs::Message for PoleLinePerception {
  type RmwMsg = super::msg::rmw::PoleLinePerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        available: msg.available,
        pole_lines: msg.pole_lines
          .into_iter()
          .map(|elem| super::msg::PoleLine::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      available: msg.available,
        pole_lines: msg.pole_lines
          .iter()
          .map(|elem| super::msg::PoleLine::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      available: msg.available,
      pole_lines: msg.pole_lines
          .into_iter()
          .map(super::msg::PoleLine::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__PoleLinePoint

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLinePoint {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::msg::Point2f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility: f32,

}



impl Default for PoleLinePoint {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PoleLinePoint::default())
  }
}

impl rosidl_runtime_rs::Message for PoleLinePoint {
  type RmwMsg = super::msg::rmw::PoleLinePoint;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        position: super::msg::Point2f::into_rmw_message(std::borrow::Cow::Owned(msg.position)).into_owned(),
        visibility: msg.visibility,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        position: super::msg::Point2f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.position)).into_owned(),
      visibility: msg.visibility,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      position: super::msg::Point2f::from_rmw_message(msg.position),
      visibility: msg.visibility,
    }
  }
}


// Corresponds to perception_msg__msg__PoleLineTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PoleLineTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for PoleLineTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PoleLineTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for PoleLineTypeEnum {
  type RmwMsg = super::msg::rmw::PoleLineTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__Polygon3d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Polygon3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub points: Vec<super::msg::Point3d>,

}



impl Default for Polygon3d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Polygon3d::default())
  }
}

impl rosidl_runtime_rs::Message for Polygon3d {
  type RmwMsg = super::msg::rmw::Polygon3d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        points: msg.points
          .into_iter()
          .map(|elem| super::msg::Point3d::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        points: msg.points
          .iter()
          .map(|elem| super::msg::Point3d::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      points: msg.points
          .into_iter()
          .map(super::msg::Point3d::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__Polygon3f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Polygon3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub points: Vec<super::msg::Point3f>,

}



impl Default for Polygon3f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Polygon3f::default())
  }
}

impl rosidl_runtime_rs::Message for Polygon3f {
  type RmwMsg = super::msg::rmw::Polygon3f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        points: msg.points
          .into_iter()
          .map(|elem| super::msg::Point3f::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        points: msg.points
          .iter()
          .map(|elem| super::msg::Point3f::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      points: msg.points
          .into_iter()
          .map(super::msg::Point3f::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__Rect4d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Rect4d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub left: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub top: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: f64,

}



impl Default for Rect4d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Rect4d::default())
  }
}

impl rosidl_runtime_rs::Message for Rect4d {
  type RmwMsg = super::msg::rmw::Rect4d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        left: msg.left,
        top: msg.top,
        right: msg.right,
        bottom: msg.bottom,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      left: msg.left,
      top: msg.top,
      right: msg.right,
      bottom: msg.bottom,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      left: msg.left,
      top: msg.top,
      right: msg.right,
      bottom: msg.bottom,
    }
  }
}


// Corresponds to perception_msg__msg__Rect4f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Rect4f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub left: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub top: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: f32,

}



impl Default for Rect4f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Rect4f::default())
  }
}

impl rosidl_runtime_rs::Message for Rect4f {
  type RmwMsg = super::msg::rmw::Rect4f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        left: msg.left,
        top: msg.top,
        right: msg.right,
        bottom: msg.bottom,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      left: msg.left,
      top: msg.top,
      right: msg.right,
      bottom: msg.bottom,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      left: msg.left,
      top: msg.top,
      right: msg.right,
      bottom: msg.bottom,
    }
  }
}


// Corresponds to perception_msg__msg__Shape2d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape2d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Shape2d::default())
  }
}

impl rosidl_runtime_rs::Message for Shape2d {
  type RmwMsg = super::msg::rmw::Shape2d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        height: msg.height,
        width: msg.width,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      height: msg.height,
      width: msg.width,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      height: msg.height,
      width: msg.width,
    }
  }
}


// Corresponds to perception_msg__msg__Shape2f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f32,

}



impl Default for Shape2f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Shape2f::default())
  }
}

impl rosidl_runtime_rs::Message for Shape2f {
  type RmwMsg = super::msg::rmw::Shape2f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        height: msg.height,
        width: msg.width,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      height: msg.height,
      width: msg.width,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      height: msg.height,
      width: msg.width,
    }
  }
}


// Corresponds to perception_msg__msg__Shape3d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape3d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Shape3d::default())
  }
}

impl rosidl_runtime_rs::Message for Shape3d {
  type RmwMsg = super::msg::rmw::Shape3d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        height: msg.height,
        length: msg.length,
        width: msg.width,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      height: msg.height,
      length: msg.length,
      width: msg.width,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      height: msg.height,
      length: msg.length,
      width: msg.width,
    }
  }
}


// Corresponds to perception_msg__msg__Shape3f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Shape3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub height: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub width: f64,

}



impl Default for Shape3f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Shape3f::default())
  }
}

impl rosidl_runtime_rs::Message for Shape3f {
  type RmwMsg = super::msg::rmw::Shape3f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        height: msg.height,
        length: msg.length,
        width: msg.width,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      height: msg.height,
      length: msg.length,
      width: msg.width,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      height: msg.height,
      length: msg.length,
      width: msg.width,
    }
  }
}


// Corresponds to perception_msg__msg__Sign

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Sign {

    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_source: super::msg::CameraSourceEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub camera_model: super::msg::CameraModelEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub score: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points_2d: Vec<super::msg::SignPoint>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub track_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shape_info: super::msg::SignShapeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bounding_box_2d: super::msg::Rect4f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_info: super::msg::SignTypeEnum,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_multi_cam: bool,

}



impl Default for Sign {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Sign::default())
  }
}

impl rosidl_runtime_rs::Message for Sign {
  type RmwMsg = super::msg::rmw::Sign;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Owned(msg.camera_model)).into_owned(),
        score: msg.score,
        points_2d: msg.points_2d
          .into_iter()
          .map(|elem| super::msg::SignPoint::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        track_id: msg.track_id,
        shape_info: super::msg::SignShapeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.shape_info)).into_owned(),
        bounding_box_2d: super::msg::Rect4f::into_rmw_message(std::borrow::Cow::Owned(msg.bounding_box_2d)).into_owned(),
        type_info: super::msg::SignTypeEnum::into_rmw_message(std::borrow::Cow::Owned(msg.type_info)).into_owned(),
        is_multi_cam: msg.is_multi_cam,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        camera_source: super::msg::CameraSourceEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_source)).into_owned(),
        camera_model: super::msg::CameraModelEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.camera_model)).into_owned(),
      score: msg.score,
        points_2d: msg.points_2d
          .iter()
          .map(|elem| super::msg::SignPoint::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      track_id: msg.track_id,
        shape_info: super::msg::SignShapeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.shape_info)).into_owned(),
        bounding_box_2d: super::msg::Rect4f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.bounding_box_2d)).into_owned(),
        type_info: super::msg::SignTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_info)).into_owned(),
      is_multi_cam: msg.is_multi_cam,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      camera_source: super::msg::CameraSourceEnum::from_rmw_message(msg.camera_source),
      camera_model: super::msg::CameraModelEnum::from_rmw_message(msg.camera_model),
      score: msg.score,
      points_2d: msg.points_2d
          .into_iter()
          .map(super::msg::SignPoint::from_rmw_message)
          .collect(),
      track_id: msg.track_id,
      shape_info: super::msg::SignShapeEnum::from_rmw_message(msg.shape_info),
      bounding_box_2d: super::msg::Rect4f::from_rmw_message(msg.bounding_box_2d),
      type_info: super::msg::SignTypeEnum::from_rmw_message(msg.type_info),
      is_multi_cam: msg.is_multi_cam,
    }
  }
}


// Corresponds to perception_msg__msg__SignPerception

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignPerception {

    // This member is not documented.
    #[allow(missing_docs)]
    pub available: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub signs: Vec<super::msg::Sign>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved_infos: Vec<std::string::String>,

}



impl Default for SignPerception {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SignPerception::default())
  }
}

impl rosidl_runtime_rs::Message for SignPerception {
  type RmwMsg = super::msg::rmw::SignPerception;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        available: msg.available,
        signs: msg.signs
          .into_iter()
          .map(|elem| super::msg::Sign::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      available: msg.available,
        signs: msg.signs
          .iter()
          .map(|elem| super::msg::Sign::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        reserved_infos: msg.reserved_infos
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      available: msg.available,
      signs: msg.signs
          .into_iter()
          .map(super::msg::Sign::from_rmw_message)
          .collect(),
      reserved_infos: msg.reserved_infos
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__SignPoint

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignPoint {

    // This member is not documented.
    #[allow(missing_docs)]
    pub position: super::msg::Point2f,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visibility: f32,

}



impl Default for SignPoint {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SignPoint::default())
  }
}

impl rosidl_runtime_rs::Message for SignPoint {
  type RmwMsg = super::msg::rmw::SignPoint;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        position: super::msg::Point2f::into_rmw_message(std::borrow::Cow::Owned(msg.position)).into_owned(),
        visibility: msg.visibility,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        position: super::msg::Point2f::into_rmw_message(std::borrow::Cow::Borrowed(&msg.position)).into_owned(),
      visibility: msg.visibility,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      position: super::msg::Point2f::from_rmw_message(msg.position),
      visibility: msg.visibility,
    }
  }
}


// Corresponds to perception_msg__msg__SignShapeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignShapeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for SignShapeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SignShapeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for SignShapeEnum {
  type RmwMsg = super::msg::rmw::SignShapeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__SignTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SignTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for SignTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SignTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for SignTypeEnum {
  type RmwMsg = super::msg::rmw::SignTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__Vector2d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector2d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,

}



impl Default for Vector2d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Vector2d::default())
  }
}

impl rosidl_runtime_rs::Message for Vector2d {
  type RmwMsg = super::msg::rmw::Vector2d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
    }
  }
}


// Corresponds to perception_msg__msg__Vector2f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector2f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,

}



impl Default for Vector2f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Vector2f::default())
  }
}

impl rosidl_runtime_rs::Message for Vector2f {
  type RmwMsg = super::msg::rmw::Vector2f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
    }
  }
}


// Corresponds to perception_msg__msg__Vector3d

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector3d {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f64,

}



impl Default for Vector3d {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Vector3d::default())
  }
}

impl rosidl_runtime_rs::Message for Vector3d {
  type RmwMsg = super::msg::rmw::Vector3d;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
        z: msg.z,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      z: msg.z,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
      z: msg.z,
    }
  }
}


// Corresponds to perception_msg__msg__Vector3f

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Vector3f {

    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,

}



impl Default for Vector3f {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Vector3f::default())
  }
}

impl rosidl_runtime_rs::Message for Vector3f {
  type RmwMsg = super::msg::rmw::Vector3f;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        x: msg.x,
        y: msg.y,
        z: msg.z,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      x: msg.x,
      y: msg.y,
      z: msg.z,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      x: msg.x,
      y: msg.y,
      z: msg.z,
    }
  }
}


// Corresponds to perception_msg__msg__VoxelGroundTypes

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelGroundTypes {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_ground_type: Vec<super::msg::GroundTypeEnum>,

}



impl Default for VoxelGroundTypes {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::VoxelGroundTypes::default())
  }
}

impl rosidl_runtime_rs::Message for VoxelGroundTypes {
  type RmwMsg = super::msg::rmw::VoxelGroundTypes;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_ground_type: msg.voxel_ground_type
          .into_iter()
          .map(|elem| super::msg::GroundTypeEnum::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_ground_type: msg.voxel_ground_type
          .iter()
          .map(|elem| super::msg::GroundTypeEnum::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      voxel_ground_type: msg.voxel_ground_type
          .into_iter()
          .map(super::msg::GroundTypeEnum::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__VoxelStates

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelStates {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_states: Vec<u8>,

}



impl Default for VoxelStates {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::VoxelStates::default())
  }
}

impl rosidl_runtime_rs::Message for VoxelStates {
  type RmwMsg = super::msg::rmw::VoxelStates;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_states: msg.voxel_states.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_states: msg.voxel_states.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      voxel_states: msg.voxel_states
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__VoxelTypes

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VoxelTypes {

    // This member is not documented.
    #[allow(missing_docs)]
    pub voxel_types: Vec<u8>,

}



impl Default for VoxelTypes {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::VoxelTypes::default())
  }
}

impl rosidl_runtime_rs::Message for VoxelTypes {
  type RmwMsg = super::msg::rmw::VoxelTypes;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_types: msg.voxel_types.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        voxel_types: msg.voxel_types.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      voxel_types: msg.voxel_types
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to perception_msg__msg__VsuSubTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VsuSubTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for VsuSubTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::VsuSubTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for VsuSubTypeEnum {
  type RmwMsg = super::msg::rmw::VsuSubTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to perception_msg__msg__VsuTypeEnum

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VsuTypeEnum {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for VsuTypeEnum {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::VsuTypeEnum::default())
  }
}

impl rosidl_runtime_rs::Message for VsuTypeEnum {
  type RmwMsg = super::msg::rmw::VsuTypeEnum;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


