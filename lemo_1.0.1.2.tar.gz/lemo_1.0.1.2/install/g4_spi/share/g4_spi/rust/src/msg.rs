#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to g4_spi__msg__MotorCanFrame
/// One-byte motor identifier.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MotorCanFrame {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: u16,

    /// Eight-byte CAN data payload.
    pub data: [u8; 8],

}



impl Default for MotorCanFrame {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MotorCanFrame::default())
  }
}

impl rosidl_runtime_rs::Message for MotorCanFrame {
  type RmwMsg = super::msg::rmw::MotorCanFrame;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: msg.id,
        data: msg.data,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      id: msg.id,
        data: msg.data,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: msg.id,
      data: msg.data,
    }
  }
}


// Corresponds to g4_spi__msg__MotorData

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MotorData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub can_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,

}



impl Default for MotorData {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MotorData::default())
  }
}

impl rosidl_runtime_rs::Message for MotorData {
  type RmwMsg = super::msg::rmw::MotorData;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        can_id: msg.can_id,
        arm_id: msg.arm_id,
        data: msg.data.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      can_id: msg.can_id,
      arm_id: msg.arm_id,
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      can_id: msg.can_id,
      arm_id: msg.arm_id,
      data: msg.data.into(),
    }
  }
}


// Corresponds to g4_spi__msg__A1zFrame
/// CAN data for motors 1 through 6. Motor IDs are 1 through 6.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct A1zFrame {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,

    /// 1是左臂，2是右臂
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub motors: [super::msg::MotorCanFrame; 6],

}



impl Default for A1zFrame {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::A1zFrame::default())
  }
}

impl rosidl_runtime_rs::Message for A1zFrame {
  type RmwMsg = super::msg::rmw::A1zFrame;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        arm_id: msg.arm_id,
        motors: msg.motors
          .map(|elem| super::msg::MotorCanFrame::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned()),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      arm_id: msg.arm_id,
        motors: msg.motors
          .iter()
          .map(|elem| super::msg::MotorCanFrame::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect::<Vec<_>>()
          .try_into()
          .unwrap(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      arm_id: msg.arm_id,
      motors: msg.motors
        .map(super::msg::MotorCanFrame::from_rmw_message),
    }
  }
}


// Corresponds to g4_spi__msg__A1zLeaderStatus
/// Bit i in each valid mask indicates whether device i (1..7) is connected.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct A1zLeaderStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub left_connect_mask: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub left_servo_error: [u8; 7],


    // This member is not documented.
    #[allow(missing_docs)]
    pub right_connect_mask: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right_servo_error: [u8; 7],

}



impl Default for A1zLeaderStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::A1zLeaderStatus::default())
  }
}

impl rosidl_runtime_rs::Message for A1zLeaderStatus {
  type RmwMsg = super::msg::rmw::A1zLeaderStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        left_connect_mask: msg.left_connect_mask,
        left_servo_error: msg.left_servo_error,
        right_connect_mask: msg.right_connect_mask,
        right_servo_error: msg.right_servo_error,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      left_connect_mask: msg.left_connect_mask,
        left_servo_error: msg.left_servo_error,
      right_connect_mask: msg.right_connect_mask,
        right_servo_error: msg.right_servo_error,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      left_connect_mask: msg.left_connect_mask,
      left_servo_error: msg.left_servo_error,
      right_connect_mask: msg.right_connect_mask,
      right_servo_error: msg.right_servo_error,
    }
  }
}


// Corresponds to g4_spi__msg__Claw
/// Claw state byte from the final byte of an A1Z frame.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Claw {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: [u8; 8],

}



impl Default for Claw {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Claw::default())
  }
}

impl rosidl_runtime_rs::Message for Claw {
  type RmwMsg = super::msg::rmw::Claw;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        data: msg.data,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        data: msg.data,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      data: msg.data,
    }
  }
}


// Corresponds to g4_spi__msg__ServoStates
/// Seven servos; fields at the same index belong to the same servo.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoStates {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: [u32; 7],


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: [i32; 7],

}



impl Default for ServoStates {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ServoStates::default())
  }
}

impl rosidl_runtime_rs::Message for ServoStates {
  type RmwMsg = super::msg::rmw::ServoStates;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        position: msg.position,
        velocity: msg.velocity,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        position: msg.position,
        velocity: msg.velocity,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      position: msg.position,
      velocity: msg.velocity,
    }
  }
}


// Corresponds to g4_spi__msg__KeyMsg

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KeyMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_x: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_y: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub keyyg_pressed: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub three_mode: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub key_pressed: u8,

}



impl Default for KeyMsg {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::KeyMsg::default())
  }
}

impl rosidl_runtime_rs::Message for KeyMsg {
  type RmwMsg = super::msg::rmw::KeyMsg;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        raw_x: msg.raw_x,
        raw_y: msg.raw_y,
        keyyg_pressed: msg.keyyg_pressed,
        three_mode: msg.three_mode,
        key_pressed: msg.key_pressed,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      raw_x: msg.raw_x,
      raw_y: msg.raw_y,
      keyyg_pressed: msg.keyyg_pressed,
      three_mode: msg.three_mode,
      key_pressed: msg.key_pressed,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      raw_x: msg.raw_x,
      raw_y: msg.raw_y,
      keyyg_pressed: msg.keyyg_pressed,
      three_mode: msg.three_mode,
      key_pressed: msg.key_pressed,
    }
  }
}


// Corresponds to g4_spi__msg__ServoCtrl

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoCtrl {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cmd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,

}



impl Default for ServoCtrl {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ServoCtrl::default())
  }
}

impl rosidl_runtime_rs::Message for ServoCtrl {
  type RmwMsg = super::msg::rmw::ServoCtrl;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        arm_id: msg.arm_id,
        servo_id: msg.servo_id,
        cmd: msg.cmd,
        length: msg.length,
        data: msg.data.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      arm_id: msg.arm_id,
      servo_id: msg.servo_id,
      cmd: msg.cmd,
      length: msg.length,
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      arm_id: msg.arm_id,
      servo_id: msg.servo_id,
      cmd: msg.cmd,
      length: msg.length,
      data: msg.data.into(),
    }
  }
}


