# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(g4_spi_IDL_FILES "msg/MotorCanFrame.idl;msg/MotorData.idl;msg/A1zFrame.idl;msg/A1zLeaderStatus.idl;msg/Claw.idl;msg/ServoStates.idl;msg/KeyMsg.idl;msg/ServoCtrl.idl")
set(g4_spi_INTERFACE_FILES "msg/MotorCanFrame.msg;msg/MotorData.msg;msg/A1zFrame.msg;msg/A1zLeaderStatus.msg;msg/Claw.msg;msg/ServoStates.msg;msg/KeyMsg.msg;msg/ServoCtrl.msg")
