#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""replay_bag.py —— 把 episode mcap 里的 /motion_target/* 按原始时序重发。

用途:播一条遥操录的好包,隔离"运控链 vs 目标源"——录的目标是 200Hz 稠密
流,若重放丝滑则 arm_bridge/SDK/电机链无责,推理端问题锁定在目标源上游。

安全:
- 默认 dry-run(只打印统计不发目标);--execute 才真正驱动机械臂
- 执行流程:先平滑对齐到包起点(首帧偏差 > --max-start-rad 时自动进入,
  速度限 --align-vmax rad/s),再正式回放,播完自动平滑回零(双臂关节回 0、
  夹爪打开;--no-home-after 关闭)。首帧偏差超 --max-align-rad(默认 2.0 rad
  ≈115°)仍拒绝执行(数据/位姿大概率有误),--force 可绕过(不推荐)
- 单写仲裁门控:仅当 /run_mode/state 的 mode=="REPLAY" 且新鲜(2s 租约
  TTL,teleop_bridge 1Hz 续约)才允许执行与播送;对齐/回放/回零全程巡检,
  模式离开 REPLAY 或仲裁者失联立即停发退出。发布帧统一覆写
  header.frame_id="lemo_src/replay",arm_bridge 消费端按模式校验许可源。
- 用 lemo 栈请先正常起栈(arm_bridge 在跑),经 dashboard 播包卡片进入
  REPLAY 模式;--force 仅用于台架调试(绕过仲裁,双重写入会打架!)

用法:
  python3 scripts/replay_bag.py <episode_dir_or_mcap>            # dry-run 统计
  python3 scripts/replay_bag.py <episode_dir> --execute          # 真播(需 REPLAY 模式)
  python3 scripts/replay_bag.py <episode_dir> --execute --speed 0.5
"""

import argparse
import glob
import json
import os
import sys
import time

import numpy as np
import rclpy
from rclpy.qos import (DurabilityPolicy, HistoryPolicy, QoSProfile,
                       ReliabilityPolicy)
from rosbag2_py import ConverterOptions, SequentialReader, StorageOptions
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import JointState
from std_msgs.msg import String

# [run_mode 门控] 与 teleop_bridge/policy_client 同一份契约(README 统一运行
# 模式节):state latched + 1Hz 续约,2s TTL;源标签写 header.frame_id
RUN_MODE_TOPIC = "/run_mode/state"
RUN_MODE_TTL_S = 2.0
TARGET_SRC_TAG = "lemo_src/replay"

ARM_TOPICS = {
    "left": "/motion_target/target_joint_state_arm_left",
    "right": "/motion_target/target_joint_state_arm_right",
}
GRIP_TOPICS = {
    "left": "/motion_target/target_position_gripper_left",
    "right": "/motion_target/target_position_gripper_right",
}
FB_TOPICS = {
    "left": "/hdas/feedback_arm_left",
    "right": "/hdas/feedback_arm_right",
}


def find_mcap(path):
    if os.path.isfile(path) and path.endswith(".mcap"):
        return path
    hits = sorted(glob.glob(os.path.join(path, "*.mcap")))
    if not hits:
        raise SystemExit(f"找不到 mcap: {path}")
    return hits[0]


def read_messages(mcap, topics):
    reader = SequentialReader()
    reader.open(StorageOptions(uri=mcap, storage_id="mcap"),
                ConverterOptions("", ""))
    msgs = []
    while reader.has_next():
        topic, data, t = reader.read_next()
        if topic in topics:
            msgs.append((t, topic, deserialize_message(data, JointState)))
    msgs.sort(key=lambda x: x[0])
    return msgs


def read_lerobot_episode(ds_dir, episode_idx, with_gripper):
    """读 LeRobot v2.1 数据集的 action 列,转成与 mcap 路径同构的
    (t_ns, topic, JointState) 序列(时戳为相对首帧 ns)。"""
    import json as _json
    import pyarrow.parquet as pq

    info = _json.load(open(os.path.join(ds_dir, "meta", "info.json")))
    fps = float(info["fps"])
    hits = sorted(glob.glob(os.path.join(
        ds_dir, "data", "chunk-*", "episode_%06d.parquet" % episode_idx)))
    if not hits:
        raise SystemExit(f"episode {episode_idx} 不存在于 {ds_dir}")
    t = pq.read_table(hits[0]).to_pydict()
    n = len(t["timestamp"])
    msgs = []
    for i in range(n):
        t_ns = int(i / fps * 1e9)
        for side in ("left", "right"):
            arm = JointState()
            arm.position = [float(x) for x in t[f"action.{side}_arm"][i]]
            arm.velocity = [0.0] * 6
            msgs.append((t_ns, ARM_TOPICS[side], arm))
            if with_gripper:
                grip = JointState()
                grip.position = [float(t[f"action.{side}_gripper"][i][0]
                                       if isinstance(t[f"action.{side}_gripper"][i], (list, tuple))
                                       else t[f"action.{side}_gripper"][i])]
                grip.velocity = [0.0]
                msgs.append((t_ns, GRIP_TOPICS[side], grip))
    msgs.sort(key=lambda x: x[0])
    return fps, msgs


def main():
    ap = argparse.ArgumentParser(description="episode mcap 目标重放(隔离运控链)")
    ap.add_argument("path", help="episode 目录/.mcap 文件/LeRobot 数据集目录")
    ap.add_argument("--episode", type=int, default=0,
                    help="LeRobot 模式:播第几个 episode(默认 0)")
    ap.add_argument("--execute", action="store_true",
                    help="真正重发目标(默认 dry-run 只统计)")
    ap.add_argument("--speed", type=float, default=1.0, help="重放倍速(默认 1.0)")
    ap.add_argument("--max-start-rad", type=float, default=0.3,
                    help="首帧与当前反馈偏差超过该值(rad,默认 0.3)时先平滑对齐到包起点")
    ap.add_argument("--align-vmax", type=float, default=0.3,
                    help="对齐/回零移动的速度上限(rad/s,默认 0.3)")
    ap.add_argument("--max-align-rad", type=float, default=2.0,
                    help="首帧偏差硬上限(rad,默认 2.0≈115°):超过仍拒绝执行")
    ap.add_argument("--force", action="store_true", help="跳过首帧偏差检查与对齐(不推荐)")
    ap.add_argument("--no-home-after", action="store_true",
                    help="播完不回零(默认播完平滑回零:双臂回 0、夹爪打开)")
    ap.add_argument("--no-gripper", action="store_true", help="不重放夹爪目标")
    args = ap.parse_args()

    if args.speed <= 0:
        raise SystemExit("--speed 必须为正")

    lerobot_mode = os.path.isfile(os.path.join(args.path, "meta", "info.json"))
    if lerobot_mode:
        fps, msgs = read_lerobot_episode(
            args.path, args.episode, not args.no_gripper)
        print(f"[replay] LeRobot episode {args.episode} @ {fps:.0f}Hz,"
              f" {len(msgs)} 条(数据源 {args.path})", flush=True)
    else:
        mcap = find_mcap(args.path)
        topics = set(ARM_TOPICS.values())
        if not args.no_gripper:
            topics |= set(GRIP_TOPICS.values())
        print(f"[replay] 读取 {mcap} …", flush=True)
        msgs = read_messages(mcap, topics)
    if not msgs:
        raise SystemExit("包里没有 /motion_target/* 消息")

    t0 = msgs[0][0]
    dur = (msgs[-1][0] - t0) / 1e9
    per_topic = {}
    for _, topic, _ in msgs:
        per_topic[topic] = per_topic.get(topic, 0) + 1
    print(f"[replay] 时长 {dur:.1f}s,消息 {len(msgs)} 条:")
    for topic, n in sorted(per_topic.items()):
        print(f"  {topic}: {n} 条 ({n / max(dur, 1e-6):.0f}Hz)")

    if not args.execute:
        print("[replay] dry-run 结束(加 --execute 才真正驱动机械臂)")
        return

    rclpy.init()
    node = rclpy.create_node("replay_bag")
    qos_be = QoSProfile(depth=1)
    qos_be.reliability = ReliabilityPolicy.BEST_EFFORT
    qos_be.history = HistoryPolicy.KEEP_LAST
    qos_rel = QoSProfile(depth=1)
    pubs = {}
    for side, topic in ARM_TOPICS.items():
        pubs[topic] = node.create_publisher(JointState, topic, qos_be)
    for side, topic in GRIP_TOPICS.items():
        pubs[topic] = node.create_publisher(JointState, topic, qos_rel)

    # ── /run_mode/state 订阅(单写仲裁门控依据)─────────────────────────
    run_state = {"mode": None, "t": 0.0}
    qos_latched = QoSProfile(depth=1)
    qos_latched.reliability = ReliabilityPolicy.RELIABLE
    qos_latched.durability = DurabilityPolicy.TRANSIENT_LOCAL
    qos_latched.history = HistoryPolicy.KEEP_LAST

    def _on_run_state(m):
        try:
            run_state["mode"] = json.loads(m.data).get("mode")
        except Exception:
            run_state["mode"] = None
        run_state["t"] = time.monotonic()

    node.create_subscription(String, RUN_MODE_TOPIC, _on_run_state, qos_latched)

    def run_mode_ok():
        return (run_state["mode"] == "REPLAY"
                and time.monotonic() - run_state["t"] <= RUN_MODE_TTL_S)

    # 首帧位姿 vs 当前反馈检查(反馈持续更新,供对齐/回零全程读最新值)
    first_arm = {}
    first_grip = {}
    for _, topic, msg in msgs:
        for side, at in ARM_TOPICS.items():
            if topic == at and side not in first_arm and len(msg.position) >= 6:
                first_arm[side] = np.asarray(msg.position[:6])
        for side, gt in GRIP_TOPICS.items():
            if topic == gt and side not in first_grip and len(msg.position) >= 1:
                first_grip[side] = float(msg.position[0])
    fb = {}
    for side, topic in FB_TOPICS.items():
        def cb(m, s=side):
            if len(m.position) >= 6:
                fb[s] = np.asarray(m.position[:6])
        node.create_subscription(JointState, topic, cb, qos_be)
    fb_grip = {}
    GRIP_FB_TOPICS = {
        "left": "/hdas/feedback_gripper_left",
        "right": "/hdas/feedback_gripper_right",
    }
    for side, topic in GRIP_FB_TOPICS.items():
        def cb_grip(m, s=side):
            if len(m.position) >= 1:
                fb_grip[s] = float(m.position[0])
        node.create_subscription(JointState, topic, cb_grip, qos_be)
    t_deadline = time.monotonic() + 5.0
    while len(fb) < 2 and time.monotonic() < t_deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    if len(fb) < 2:
        node.destroy_node(); rclpy.shutdown()
        raise SystemExit("[replay] 读不到双臂 feedback,栈没在跑?拒绝执行")

    worst = 0.0
    for side in ("left", "right"):
        if side not in first_arm:
            continue
        dev = float(np.max(np.abs(first_arm[side] - fb[side])))
        worst = max(worst, dev)
        print(f"[replay] {side} 首帧偏差 {np.degrees(dev):.1f}°", flush=True)
    if worst > args.max_align_rad and not args.force:
        node.destroy_node(); rclpy.shutdown()
        raise SystemExit(
            f"[replay] 首帧偏差 {np.degrees(worst):.1f}° 超过硬上限 "
            f"{np.degrees(args.max_align_rad):.1f}°,数据/位姿大概率有误,"
            "拒绝执行。确认无误后用 --force(不推荐)")

    # 单写仲裁门控:仅在 REPLAY 模式持有写入权(dashboard 播包卡片会先切模式)
    t_deadline = time.monotonic() + 3.0
    while run_state["mode"] is None and time.monotonic() < t_deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    if not run_mode_ok():
        if args.force:
            print(f"[replay] 警告: 当前运行模式={run_state['mode']},--force 绕过"
                  "单写仲裁——若 teleop/policy 也在发目标将双写打架!", flush=True)
        else:
            node.destroy_node(); rclpy.shutdown()
            raise SystemExit(
                f"[replay] 当前运行模式={run_state['mode']}(需 REPLAY 且新鲜),"
                "拒绝执行。请经 dashboard 播包卡片启动(自动切 REPLAY),"
                "或确认无其他目标源后用 --force(不推荐)")

    # ── 平滑移动(对齐到包起点/播完回零共用)────────────────────────────
    def publish_pose(arm_pos, grip_pos):
        stamp = node.get_clock().now().to_msg()
        for side, topic in ARM_TOPICS.items():
            if side in arm_pos:
                m = JointState()
                m.header.stamp = stamp
                m.header.frame_id = TARGET_SRC_TAG
                m.position = [float(x) for x in arm_pos[side]]
                m.velocity = [0.0] * 6
                pubs[topic].publish(m)
        if not args.no_gripper:
            for side, topic in GRIP_TOPICS.items():
                if side in grip_pos:
                    m = JointState()
                    m.header.stamp = stamp
                    m.header.frame_id = TARGET_SRC_TAG
                    m.position = [float(grip_pos[side])]
                    m.velocity = [0.0]
                    pubs[topic].publish(m)

    def smooth_move(target_arm, target_grip, label):
        """三次平滑(零起停速度)从当前反馈移到目标,速度上限 align_vmax。"""
        cur_arm = {s: fb[s].copy() for s in target_arm if s in fb}
        cur_grip = {s: fb_grip.get(s, target_grip[s]) for s in target_grip}
        dev = max(
            [float(np.max(np.abs(target_arm[s] - cur_arm[s])))
             for s in target_arm if s in cur_arm]
            + [abs(target_grip[s] * 0.01 - cur_grip[s] * 0.01)
               for s in target_grip]  # 夹爪百分比折算参与时长估计
        )
        dur = max(1.0, dev / args.align_vmax)
        print(f"[replay] {label}: 最大偏差 {np.degrees(dev):.1f}°,"
              f"平滑移动 {dur:.1f}s", flush=True)
        steps = max(1, int(dur * 50))
        last_check = 0.0
        for k in range(steps + 1):
            if time.monotonic() - last_check > 0.05:
                rclpy.spin_once(node, timeout_sec=0)
                last_check = time.monotonic()
                if not run_mode_ok():
                    print(f"\n[replay] {label}中模式离开 REPLAY/仲裁者失联,"
                          "立即停发", flush=True)
                    raise SystemExit(3)
            a = k / steps
            a = a * a * (3.0 - 2.0 * a)  # smoothstep: 两端零速度
            pose_arm = {s: cur_arm[s] + (target_arm[s] - cur_arm[s]) * a
                        for s in cur_arm}
            pose_grip = {s: cur_grip[s] + (target_grip[s] - cur_grip[s]) * a
                         for s in cur_grip}
            publish_pose(pose_arm, pose_grip)
            time.sleep(0.02)
        # 到位后再等一拍,让 bridge 平滑收敛
        time.sleep(0.5)

    # 首帧偏差大 → 先平滑对齐到包起点(--force 跳过)
    if worst > args.max_start_rad and not args.force:
        smooth_move(first_arm, first_grip, "对齐到包起点")

    print(f"[replay] 3s 后开始,时长 {dur / args.speed:.1f}s,"
          f"Ctrl+C 立即停发(bridge 500ms 后自动保持)", flush=True)
    try:
        time.sleep(3.0)
        start = time.monotonic()
        n = len(msgs)
        last_gate_check = 0.0
        for idx, (t, topic, msg) in enumerate(msgs):
            wait = start + (t - t0) / 1e9 / args.speed - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            # 门控巡检(50ms 一档):模式离开 REPLAY/仲裁者失联 → 立即停发退出
            if time.monotonic() - last_gate_check > 0.05:
                rclpy.spin_once(node, timeout_sec=0)
                last_gate_check = time.monotonic()
                if not run_mode_ok():
                    print("\n[replay] 运行模式已离开 REPLAY 或仲裁者失联,"
                          "立即停发", flush=True)
                    raise SystemExit(3)
            msg.header.frame_id = TARGET_SRC_TAG
            pubs[topic].publish(msg)
            # 进度行(dashboard 解析;每 2% 或最后一行)
            if idx % max(1, n // 50) == 0 or idx == n - 1:
                print(f"[replay] PROGRESS {idx + 1}/{n}", flush=True)
        print("[replay] 播完,已停发(bridge 将保持)", flush=True)
        # 播完平滑回零:双臂关节回 0、夹爪打开(100=打开)
        if not args.no_home_after:
            zero_arm = {s: np.zeros(6) for s in first_arm}
            open_grip = {s: 100.0 for s in first_grip}
            if zero_arm:
                smooth_move(zero_arm, open_grip, "回零")
                print("[replay] 回零完成", flush=True)
    except KeyboardInterrupt:
        print("\n[replay] 手动中止,已停发", flush=True)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
