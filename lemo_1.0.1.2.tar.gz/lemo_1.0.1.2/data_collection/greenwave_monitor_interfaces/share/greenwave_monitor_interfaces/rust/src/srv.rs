#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ManageTopic_Request {
    /// Request
    pub topic_name: std::string::String,

    /// true to add, false to remove
    pub add_topic: bool,

}



impl Default for ManageTopic_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ManageTopic_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ManageTopic_Request {
  type RmwMsg = super::srv::rmw::ManageTopic_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        topic_name: msg.topic_name.as_str().into(),
        add_topic: msg.add_topic,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        topic_name: msg.topic_name.as_str().into(),
      add_topic: msg.add_topic,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      topic_name: msg.topic_name.to_string(),
      add_topic: msg.add_topic,
    }
  }
}


// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ManageTopic_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for ManageTopic_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ManageTopic_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ManageTopic_Response {
  type RmwMsg = super::srv::rmw::ManageTopic_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetExpectedFrequency_Request {
    /// Request
    pub topic_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub expected_hz: f64,

    /// i.e. 5 = 5% of expected_hz
    pub tolerance_percent: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub clear_expected: bool,

    /// add topic to monitoring if not already
    pub add_topic_if_missing: bool,

}



impl Default for SetExpectedFrequency_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SetExpectedFrequency_Request::default())
  }
}

impl rosidl_runtime_rs::Message for SetExpectedFrequency_Request {
  type RmwMsg = super::srv::rmw::SetExpectedFrequency_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        topic_name: msg.topic_name.as_str().into(),
        expected_hz: msg.expected_hz,
        tolerance_percent: msg.tolerance_percent,
        clear_expected: msg.clear_expected,
        add_topic_if_missing: msg.add_topic_if_missing,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        topic_name: msg.topic_name.as_str().into(),
      expected_hz: msg.expected_hz,
      tolerance_percent: msg.tolerance_percent,
      clear_expected: msg.clear_expected,
      add_topic_if_missing: msg.add_topic_if_missing,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      topic_name: msg.topic_name.to_string(),
      expected_hz: msg.expected_hz,
      tolerance_percent: msg.tolerance_percent,
      clear_expected: msg.clear_expected,
      add_topic_if_missing: msg.add_topic_if_missing,
    }
  }
}


// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetExpectedFrequency_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for SetExpectedFrequency_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SetExpectedFrequency_Response::default())
  }
}

impl rosidl_runtime_rs::Message for SetExpectedFrequency_Response {
  type RmwMsg = super::srv::rmw::SetExpectedFrequency_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}






#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic() -> *const std::ffi::c_void;
}

// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic
#[allow(missing_docs, non_camel_case_types)]
pub struct ManageTopic;

impl rosidl_runtime_rs::Service for ManageTopic {
    type Request = ManageTopic_Request;
    type Response = ManageTopic_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic() }
    }
}




#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency() -> *const std::ffi::c_void;
}

// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency
#[allow(missing_docs, non_camel_case_types)]
pub struct SetExpectedFrequency;

impl rosidl_runtime_rs::Service for SetExpectedFrequency {
    type Request = SetExpectedFrequency_Request;
    type Response = SetExpectedFrequency_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency() }
    }
}


