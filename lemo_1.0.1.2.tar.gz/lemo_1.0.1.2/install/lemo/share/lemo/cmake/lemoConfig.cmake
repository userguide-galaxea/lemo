# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_lemo_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED lemo_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(lemo_FOUND FALSE)
  elseif(NOT lemo_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(lemo_FOUND FALSE)
  endif()
  return()
endif()
set(_lemo_CONFIG_INCLUDED TRUE)

# output package information
if(NOT lemo_FIND_QUIETLY)
  message(STATUS "Found lemo: 0.1.0 (${lemo_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'lemo' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${lemo_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(lemo_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${lemo_DIR}/${_extra}")
endforeach()
