# generated from rosidl_generator_py/resource/_idl.py.em
# with input from g4_spi:msg/A1zLeaderStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

# Member 'left_servo_error'
# Member 'right_servo_error'
import numpy  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_A1zLeaderStatus(type):
    """Metaclass of message 'A1zLeaderStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('g4_spi')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'g4_spi.msg.A1zLeaderStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__a1z_leader_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__a1z_leader_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__a1z_leader_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__a1z_leader_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__a1z_leader_status

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class A1zLeaderStatus(metaclass=Metaclass_A1zLeaderStatus):
    """Message class 'A1zLeaderStatus'."""

    __slots__ = [
        '_header',
        '_left_connect_mask',
        '_left_servo_error',
        '_right_connect_mask',
        '_right_servo_error',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'left_connect_mask': 'uint8',
        'left_servo_error': 'uint8[7]',
        'right_connect_mask': 'uint8',
        'right_servo_error': 'uint8[7]',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('uint8'), 7),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('uint8'), 7),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.left_connect_mask = kwargs.get('left_connect_mask', int())
        if 'left_servo_error' not in kwargs:
            self.left_servo_error = numpy.zeros(7, dtype=numpy.uint8)
        else:
            self.left_servo_error = kwargs.get('left_servo_error')
        self.right_connect_mask = kwargs.get('right_connect_mask', int())
        if 'right_servo_error' not in kwargs:
            self.right_servo_error = numpy.zeros(7, dtype=numpy.uint8)
        else:
            self.right_servo_error = kwargs.get('right_servo_error')

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.left_connect_mask != other.left_connect_mask:
            return False
        if any(self.left_servo_error != other.left_servo_error):
            return False
        if self.right_connect_mask != other.right_connect_mask:
            return False
        if any(self.right_servo_error != other.right_servo_error):
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def left_connect_mask(self):
        """Message field 'left_connect_mask'."""
        return self._left_connect_mask

    @left_connect_mask.setter
    def left_connect_mask(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'left_connect_mask' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'left_connect_mask' field must be an unsigned integer in [0, 255]"
        self._left_connect_mask = value

    @builtins.property
    def left_servo_error(self):
        """Message field 'left_servo_error'."""
        return self._left_servo_error

    @left_servo_error.setter
    def left_servo_error(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.uint8, \
                "The 'left_servo_error' numpy.ndarray() must have the dtype of 'numpy.uint8'"
            assert value.size == 7, \
                "The 'left_servo_error' numpy.ndarray() must have a size of 7"
            self._left_servo_error = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 7 and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 256 for val in value)), \
                "The 'left_servo_error' field must be a set or sequence with length 7 and each value of type 'int' and each unsigned integer in [0, 255]"
        self._left_servo_error = numpy.array(value, dtype=numpy.uint8)

    @builtins.property
    def right_connect_mask(self):
        """Message field 'right_connect_mask'."""
        return self._right_connect_mask

    @right_connect_mask.setter
    def right_connect_mask(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'right_connect_mask' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'right_connect_mask' field must be an unsigned integer in [0, 255]"
        self._right_connect_mask = value

    @builtins.property
    def right_servo_error(self):
        """Message field 'right_servo_error'."""
        return self._right_servo_error

    @right_servo_error.setter
    def right_servo_error(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.uint8, \
                "The 'right_servo_error' numpy.ndarray() must have the dtype of 'numpy.uint8'"
            assert value.size == 7, \
                "The 'right_servo_error' numpy.ndarray() must have a size of 7"
            self._right_servo_error = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 7 and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 256 for val in value)), \
                "The 'right_servo_error' field must be a set or sequence with length 7 and each value of type 'int' and each unsigned integer in [0, 255]"
        self._right_servo_error = numpy.array(value, dtype=numpy.uint8)
