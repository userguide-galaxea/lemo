# generated from rosidl_generator_py/resource/_idl.py.em
# with input from sensor_lidar_msg:msg/LidarStatusReport.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LidarStatusReport(type):
    """Metaclass of message 'LidarStatusReport'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('sensor_lidar_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'sensor_lidar_msg.msg.LidarStatusReport')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lidar_status_report
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lidar_status_report
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lidar_status_report
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lidar_status_report
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lidar_status_report

            from sensor_lidar_msg.msg import LidarMode
            if LidarMode.__class__._TYPE_SUPPORT is None:
                LidarMode.__class__.__import_type_support__()

            from sensor_lidar_msg.msg import LidarStatus
            if LidarStatus.__class__._TYPE_SUPPORT is None:
                LidarStatus.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LidarStatusReport(metaclass=Metaclass_LidarStatusReport):
    """Message class 'LidarStatusReport'."""

    __slots__ = [
        '_lidar_service_mode',
        '_status',
    ]

    _fields_and_field_types = {
        'lidar_service_mode': 'sensor_lidar_msg/LidarMode',
        'status': 'sequence<sensor_lidar_msg/LidarStatus>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarMode'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarStatus')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from sensor_lidar_msg.msg import LidarMode
        self.lidar_service_mode = kwargs.get('lidar_service_mode', LidarMode())
        self.status = kwargs.get('status', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.lidar_service_mode != other.lidar_service_mode:
            return False
        if self.status != other.status:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def lidar_service_mode(self):
        """Message field 'lidar_service_mode'."""
        return self._lidar_service_mode

    @lidar_service_mode.setter
    def lidar_service_mode(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarMode
            assert \
                isinstance(value, LidarMode), \
                "The 'lidar_service_mode' field must be a sub message of type 'LidarMode'"
        self._lidar_service_mode = value

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarStatus
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, LidarStatus) for v in value) and
                 True), \
                "The 'status' field must be a set or sequence and each value of type 'LidarStatus'"
        self._status = value
