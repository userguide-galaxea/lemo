from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    server_url = LaunchConfiguration('server_url')
    task = LaunchConfiguration('task')
    control_hz = LaunchConfiguration('control_hz')
    enabled = LaunchConfiguration('enabled')
    embodiment_type = LaunchConfiguration('embodiment_type')
    return LaunchDescription([
        DeclareLaunchArgument('server_url', default_value='ws://192.168.110.62:8765',
                              description='4090 推理服务器 WebSocket 地址'),
        DeclareLaunchArgument('task', default_value='',
                              description='任务描述文本（随 obs 发给 policy）'),
        DeclareLaunchArgument('control_hz', default_value='15',
                              description='action 消费/发布频率'),
        DeclareLaunchArgument('enabled', default_value='true',
                              description='总开关，false 时不发 /motion_target/*'),
        DeclareLaunchArgument('embodiment_type', default_value='galaxea_a1z',
                              description='G0.5 embodiment 名(随 obs 路由;'
                                          '须与 server eval_embodiment 一致,'
                                          'lemo 舰队为 galaxea_a1z)'),
        DeclareLaunchArgument('send_raw_jpeg', default_value='true',
                              description='true: 相机 JPEG 原字节发 server 端解码'
                                          '（需 g05 serve_policy.py 支持 __jpeg__）；'
                                          'false: 板端解码 resize 发 CHW（兼容老 server）'),
        DeclareLaunchArgument('max_joint_step_deg', default_value='10',
                              description='单帧关节增量限幅(度;中点插值减半,'
                                          '对齐 PC spike clamp 语义)'),
        DeclareLaunchArgument('prefetch_steps', default_value='20',
                              description='水位预取:队列剩 N 步即请求新 chunk'
                                          '(≈推理消耗步数+crossfade 重叠区)'),
        DeclareLaunchArgument('plan_divergence_max_deg', default_value='25',
                              description='计划分歧保护:新 chunk 与旧尾对齐区'
                                          '最大关节分歧超此值(度)即拒收'),
        DeclareLaunchArgument('interp_midpoint', default_value='true',
                              description='客户端中点插值 15→30Hz(直通类平滑'
                                          '模式需要;轨迹类 otg/cubic/bcubic 由'
                                          ' arm_bridge 重采样,应传 false)'),
        Node(
            package='policy_client',
            executable='policy-client',
            name='policy_client',
            output='both',
            parameters=[{
                'server_url': server_url,
                'task': task,
                'control_hz': ParameterValue(control_hz, value_type=float),
                'enabled': ParameterValue(enabled, value_type=bool),
                'embodiment_type': embodiment_type,
                'send_raw_jpeg': ParameterValue(
                    LaunchConfiguration('send_raw_jpeg'), value_type=bool),
                'max_joint_step_deg': ParameterValue(
                    LaunchConfiguration('max_joint_step_deg'), value_type=float),
                'prefetch_steps': ParameterValue(
                    LaunchConfiguration('prefetch_steps'), value_type=int),
                'plan_divergence_max_deg': ParameterValue(
                    LaunchConfiguration('plan_divergence_max_deg'),
                    value_type=float),
                'interp_midpoint': ParameterValue(
                    LaunchConfiguration('interp_midpoint'), value_type=bool),
            }],
        ),
    ])
